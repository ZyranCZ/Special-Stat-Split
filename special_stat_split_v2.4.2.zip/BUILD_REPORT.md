# Build report — v2.4.2

## Promotion baseline

Final release promoted directly from the accepted `special_stat_split_v2.4.2-test7` source package used in this turn, SHA-256 `c8e9402c222aef37539f683078b729cfd2e97a9895a5029d3d24c110c332fef7`. The package was verified internally as `2.4.2-test7` before modification (`manifest.json`, `main.lua`, runtime contract expectations).

The final promotion intentionally changes no gameplay or Modern UI rendering logic. The only `main.lua` change is the version comment; runtime behavior is therefore identical to test7.

## Release contents

The v2.4.2 release keeps the completed test7 presentation behavior:

- **ModernUI Party Stats Layout = 2 ROWS** (default): `ATTACK / DEFENSE / SPEED`, then `SPEC. ATTACK / SPEC. DEFENSE`.
- **ModernUI Party Stats Layout = 1 ROW**: compact `ATK / DEF / SPD / SPATK / SPDEF`.
- Party choices use one shared adaptive font scale calculated from the live panel width.
- Summary is intentionally independent of the Party toggle and always places `SP. ATTACK` and `SP. DEFENSE` on separate rows on desktop and mobile, with ID/OT moved below using Modern UI's native fallback data.

## Forward compatibility

Modern UI ordinary Party/Summary compatibility is capability-gated rather than version-number-gated. 0.8.3 and 0.8.4 are verified implementations; a compatible future version number (tested synthetically as 0.9.9) continues to install the shim. Missing/incompatible API or renderer capabilities fail closed.

## Automated verification

PASS against:

- 251/251 split-stat reference rows and 502/502 SpA/SpD values;
- 251/251 modern move categories;
- all Special/category configurations;
- standalone Move Category coexistence contracts;
- Crystal 251 contracts;
- Party/Summary layout and Modern UI capability guards;
- ModernUI Override ON/OFF, BattleWIP guards and VANILLA guards.

The test7 suite was run before promotion and the final suite was rerun after metadata/documentation conversion. The distributable ZIP keeps `manifest.json` and `main.lua` at archive root.
