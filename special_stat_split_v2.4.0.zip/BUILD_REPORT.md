# Build report — v2.4.0

**2.4.0 release focus:** restore Gen1 Modern UI's authored Party/Summary appearance 1:1 and reduce the ordinary override to a surgical split-stat text-row shim, while preserving the integrated Move Category readout and launcher update support.

Target: Gen1Recomp v0.1.75 / `60cf07fb0a1ffce0ec6d5d0d2f78a921a6d0b7da`.

## Scope

The final release is promoted from the exact **assistant-delivered `special_stat_split_v2.4.0-test3.zip`** (SHA-256 `324516bd2e8bc8e8d9031366997ef4e1d33385504fa231ac640d0df5d89074f6`). The test3 gameplay/UI implementation received live in-game confirmation before promotion. The implementation itself is unchanged in the final release; only release metadata, test expectations and documentation were cleaned up.

The test3 development line originally started from the exact **assistant-delivered `special_stat_split_v2.4.0-test2.zip`** (SHA-256 `df1aa365b3a169aca72e86388c0af76a852e8c90e43dc481dc22aa436235bdfb`). No user re-upload was used as the source baseline. Existing split-stat math, 251-move category ownership, Crystal 251 interoperability, integrated Move Category readout, save behavior and link-affecting gameplay paths are retained.

Presentation/ownership changes in test3:

- removes the ordinary generic external Party/Summary adapter introduced during the earlier compatibility experiment;
- keeps **ModernUI Override** default ON, but on the explicitly supported Modern UI 0.8.3 it now lets Modern UI render the complete screen itself and repaints only the legacy split-stat text area afterward;
- Party keeps Modern UI's list, icons, selected sprite, type, HP bar, moves/PP, frame, responsive sizing, theme and pointer behavior; only `ATK / DEF / SPD / SPC` becomes `ATK / DEF / SPD / SPATK / SPDEF`;
- Summary keeps Modern UI's complete card and geometry; only the `SPECIAL` row becomes `SP.ATK` + `SP.DEF`;
- the ordinary shim is deliberately gated to release 0.8.3 + compatibility API v1 and fails closed on unknown releases or renderer signature drift;
- **ModernUI BattleWIP Override** remains default OFF and provisional; the normal/default battle UI needs no override;
- no Modern UI source or asset is copied, bundled, or edited;
- all split-stat math, category behavior, integrated Move Category readout, updater metadata and Crystal 251 interoperability remain inherited from test2.

## Automated result

Complete suite against the exact frozen target: **PASS**.

Passed gates include:

- 251/251 split-stat reference rows and 502/502 cross-check values;
- split-stat damage/stage/screen/critical-hit controls;
- 251/251 Gen I+II modern category rows (106 Physical / 52 Special / 93 Status);
- 165/165 exact Gen1Recomp Gen I registry IDs and reused-index collision guard;
- all four Special-stat / move-category option combinations;
- integrated Move Category Readout ON/OFF and GEN I/GEN IV+ agreement;
- coexistence against the **exact provided standalone Move Category v1.0.1 `main.lua`**, including standalone enabled, standalone option disabled, and integrated option disabled combinations;
- manifest GitHub updater metadata and optional standalone dependency contract;
- Crystal 251 GEN IV+ and GEN I runtime contracts;
- exact frozen Stats/Damage/Experience/MoveEffects/ItemEffects/SaveData/Pokemon/Evolution contracts;
- Special Stat Split with Gen1 Modern UI absent;
- real Gen1 Modern UI 0.8.3 renderer execution with surgical Party stat-row and Summary SPECIAL-row repaint, plus OFF/VANILLA/fail-closed guards;
- real Modern UI 0.8.3 `ui.state.decorate` replacement of a live-shaped level-up StatBox while experimental BATTLE UI (WIP) is ON, followed by Special Stat Split post-HUD correction with SP. ATK / SP. DEF and no legacy SPECIAL label;
- real Modern UI WIP-OFF restoration and HIDE ORIGINAL UI-OFF native-draw guards, plus VANILLA and no-Modern-UI guards.

## Packaging

The ZIP keeps `manifest.json` and `main.lua` at archive root. `gen1_modern_ui` remains an optional dependency; no Modern UI source or asset is bundled.

Automated coexistence against the exact standalone Move Category v1.0.1 remains PASS. A dedicated two-peer link battle is still a recommended post-release compatibility smoke, but it is not required for single-player release promotion. The experimental Modern Battle UI bridge remains opt-in under **ModernUI BattleWIP Override** and is intentionally not treated as a final/stable integration target until Modern UI publishes a stable battle UI or cleaner extension seam.


The ownership model uses **ModernUI Override = ON** by default and **ModernUI BattleWIP Override = OFF** by default. Tests cover their independent ON/OFF matrix, deliberate fail-closed behavior for an unknown 0.9.9 release even with API v1, and unsupported API v2.

## Key file SHA-256

- `main.lua`: `a438a4ed01d4511530611bee94942c19a4351b29e877a025d252215ab7e53205`
- `manifest.json`: `b2d6094a0dbb642f8b0a497d51c9da2f7c24b2bb5b47bcb834d769a698e180eb`
- `tests/runtime_stub_contract.lua`: `79bebf87a439a141be51d7189790a239aebd45d7befecd6f930b2fff8009195a`

The distributable ZIP checksum is generated externally after packaging so it does not recursively change the artifact it describes.
