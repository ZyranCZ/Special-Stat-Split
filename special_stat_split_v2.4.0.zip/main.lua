-- SPECIAL STAT SPLIT v2.4.0
-- Release build for Gen1Recomp commit 60cf07fb0a1ffce0ec6d5d0d2f78a921a6d0b7da.
--
-- Scope: Generation II Special stat split + Generation IV+ per-move damage categories + integrated move-category battle readout.
-- Each original Gen I move can be explicitly physical/special/status independent of type.
-- The original Gen1Recomp damage formula, RNG, type handling and rulesets are preserved.
--
-- RELEASE NOTE:
-- v2.0.0 passed automated/frozen contracts and user-reported in-game smoke.
-- v2.1.0 hardened category ownership/collision behavior.
-- v2.2.2 makes the mod-owned canonical #001-251 SpA/SpD table authoritative;
-- CRYSTAL_251 exports are only audited/fallback data. v2.2.0 added optional interoperability:
-- Sp. Atk/Sp. Def for all 251 species plus GEN IV+ per-move categories for all
-- 251 Crystal move slots, including Crystal's private damage-routing path.

local MOD_ID = "special_stat_split"
local PATCH_KEY = "__special_stat_split_dispatch_v1"
local MOVE_READOUT_PATCH_KEY = "__special_stat_split_move_category_readout_v1"
local unpack = table.unpack or unpack
local function pack(...) return { n = select("#", ...), ... } end

local function escapePattern(s)
  return (tostring(s):gsub("([^%w])", "%%%1"))
end

local function relabelMessages(messages, fromLabel, toLabel)
  if type(messages) ~= "table" then return messages end
  local pat = escapePattern(fromLabel)
  for i, msg in ipairs(messages) do
    if type(msg) == "string" then
      messages[i] = msg:gsub(pat, toLabel)
    end
  end
  return messages
end

-- Mod-local helpers/data are embedded in main.lua on purpose.
-- Gen1Recomp loads the manifest entry but does not add each mod directory
-- to Lua/LÖVE require paths, so mod-local library imports are not portable in packaged builds.
local GEN2_SPECIAL_BY_ID = {
  BULBASAUR = { dex = 1, spa = 65, spd = 65 },
  IVYSAUR = { dex = 2, spa = 80, spd = 80 },
  VENUSAUR = { dex = 3, spa = 100, spd = 100 },
  CHARMANDER = { dex = 4, spa = 60, spd = 50 },
  CHARMELEON = { dex = 5, spa = 80, spd = 65 },
  CHARIZARD = { dex = 6, spa = 109, spd = 85 },
  SQUIRTLE = { dex = 7, spa = 50, spd = 64 },
  WARTORTLE = { dex = 8, spa = 65, spd = 80 },
  BLASTOISE = { dex = 9, spa = 85, spd = 105 },
  CATERPIE = { dex = 10, spa = 20, spd = 20 },
  METAPOD = { dex = 11, spa = 25, spd = 25 },
  BUTTERFREE = { dex = 12, spa = 80, spd = 80 },
  WEEDLE = { dex = 13, spa = 20, spd = 20 },
  KAKUNA = { dex = 14, spa = 25, spd = 25 },
  BEEDRILL = { dex = 15, spa = 45, spd = 80 },
  PIDGEY = { dex = 16, spa = 35, spd = 35 },
  PIDGEOTTO = { dex = 17, spa = 50, spd = 50 },
  PIDGEOT = { dex = 18, spa = 70, spd = 70 },
  RATTATA = { dex = 19, spa = 25, spd = 35 },
  RATICATE = { dex = 20, spa = 50, spd = 70 },
  SPEAROW = { dex = 21, spa = 31, spd = 31 },
  FEAROW = { dex = 22, spa = 61, spd = 61 },
  EKANS = { dex = 23, spa = 40, spd = 54 },
  ARBOK = { dex = 24, spa = 65, spd = 79 },
  PIKACHU = { dex = 25, spa = 50, spd = 40 },
  RAICHU = { dex = 26, spa = 90, spd = 80 },
  SANDSHREW = { dex = 27, spa = 20, spd = 30 },
  SANDSLASH = { dex = 28, spa = 45, spd = 55 },
  NIDORAN_F = { dex = 29, spa = 40, spd = 40 },
  NIDORINA = { dex = 30, spa = 55, spd = 55 },
  NIDOQUEEN = { dex = 31, spa = 75, spd = 85 },
  NIDORAN_M = { dex = 32, spa = 40, spd = 40 },
  NIDORINO = { dex = 33, spa = 55, spd = 55 },
  NIDOKING = { dex = 34, spa = 85, spd = 75 },
  CLEFAIRY = { dex = 35, spa = 60, spd = 65 },
  CLEFABLE = { dex = 36, spa = 85, spd = 90 },
  VULPIX = { dex = 37, spa = 50, spd = 65 },
  NINETALES = { dex = 38, spa = 81, spd = 100 },
  JIGGLYPUFF = { dex = 39, spa = 45, spd = 25 },
  WIGGLYTUFF = { dex = 40, spa = 75, spd = 50 },
  ZUBAT = { dex = 41, spa = 30, spd = 40 },
  GOLBAT = { dex = 42, spa = 65, spd = 75 },
  ODDISH = { dex = 43, spa = 75, spd = 65 },
  GLOOM = { dex = 44, spa = 85, spd = 75 },
  VILEPLUME = { dex = 45, spa = 100, spd = 90 },
  PARAS = { dex = 46, spa = 45, spd = 55 },
  PARASECT = { dex = 47, spa = 60, spd = 80 },
  VENONAT = { dex = 48, spa = 40, spd = 55 },
  VENOMOTH = { dex = 49, spa = 90, spd = 75 },
  DIGLETT = { dex = 50, spa = 35, spd = 45 },
  DUGTRIO = { dex = 51, spa = 50, spd = 70 },
  MEOWTH = { dex = 52, spa = 40, spd = 40 },
  PERSIAN = { dex = 53, spa = 65, spd = 65 },
  PSYDUCK = { dex = 54, spa = 65, spd = 50 },
  GOLDUCK = { dex = 55, spa = 95, spd = 80 },
  MANKEY = { dex = 56, spa = 35, spd = 45 },
  PRIMEAPE = { dex = 57, spa = 60, spd = 70 },
  GROWLITHE = { dex = 58, spa = 70, spd = 50 },
  ARCANINE = { dex = 59, spa = 100, spd = 80 },
  POLIWAG = { dex = 60, spa = 40, spd = 40 },
  POLIWHIRL = { dex = 61, spa = 50, spd = 50 },
  POLIWRATH = { dex = 62, spa = 70, spd = 90 },
  ABRA = { dex = 63, spa = 105, spd = 55 },
  KADABRA = { dex = 64, spa = 120, spd = 70 },
  ALAKAZAM = { dex = 65, spa = 135, spd = 85 },
  MACHOP = { dex = 66, spa = 35, spd = 35 },
  MACHOKE = { dex = 67, spa = 50, spd = 60 },
  MACHAMP = { dex = 68, spa = 65, spd = 85 },
  BELLSPROUT = { dex = 69, spa = 70, spd = 30 },
  WEEPINBELL = { dex = 70, spa = 85, spd = 45 },
  VICTREEBEL = { dex = 71, spa = 100, spd = 60 },
  TENTACOOL = { dex = 72, spa = 50, spd = 100 },
  TENTACRUEL = { dex = 73, spa = 80, spd = 120 },
  GEODUDE = { dex = 74, spa = 30, spd = 30 },
  GRAVELER = { dex = 75, spa = 45, spd = 45 },
  GOLEM = { dex = 76, spa = 55, spd = 65 },
  PONYTA = { dex = 77, spa = 65, spd = 65 },
  RAPIDASH = { dex = 78, spa = 80, spd = 80 },
  SLOWPOKE = { dex = 79, spa = 40, spd = 40 },
  SLOWBRO = { dex = 80, spa = 100, spd = 80 },
  MAGNEMITE = { dex = 81, spa = 95, spd = 55 },
  MAGNETON = { dex = 82, spa = 120, spd = 70 },
  FARFETCH_D = { dex = 83, spa = 58, spd = 62 },
  DODUO = { dex = 84, spa = 35, spd = 35 },
  DODRIO = { dex = 85, spa = 60, spd = 60 },
  SEEL = { dex = 86, spa = 45, spd = 70 },
  DEWGONG = { dex = 87, spa = 70, spd = 95 },
  GRIMER = { dex = 88, spa = 40, spd = 50 },
  MUK = { dex = 89, spa = 65, spd = 100 },
  SHELLDER = { dex = 90, spa = 45, spd = 25 },
  CLOYSTER = { dex = 91, spa = 85, spd = 45 },
  GASTLY = { dex = 92, spa = 100, spd = 35 },
  HAUNTER = { dex = 93, spa = 115, spd = 55 },
  GENGAR = { dex = 94, spa = 130, spd = 75 },
  ONIX = { dex = 95, spa = 30, spd = 45 },
  DROWZEE = { dex = 96, spa = 43, spd = 90 },
  HYPNO = { dex = 97, spa = 73, spd = 115 },
  KRABBY = { dex = 98, spa = 25, spd = 25 },
  KINGLER = { dex = 99, spa = 50, spd = 50 },
  VOLTORB = { dex = 100, spa = 55, spd = 55 },
  ELECTRODE = { dex = 101, spa = 80, spd = 80 },
  EXEGGCUTE = { dex = 102, spa = 60, spd = 45 },
  EXEGGUTOR = { dex = 103, spa = 125, spd = 65 },
  CUBONE = { dex = 104, spa = 40, spd = 50 },
  MAROWAK = { dex = 105, spa = 50, spd = 80 },
  HITMONLEE = { dex = 106, spa = 35, spd = 110 },
  HITMONCHAN = { dex = 107, spa = 35, spd = 110 },
  LICKITUNG = { dex = 108, spa = 60, spd = 75 },
  KOFFING = { dex = 109, spa = 60, spd = 45 },
  WEEZING = { dex = 110, spa = 85, spd = 70 },
  RHYHORN = { dex = 111, spa = 30, spd = 30 },
  RHYDON = { dex = 112, spa = 45, spd = 45 },
  CHANSEY = { dex = 113, spa = 35, spd = 105 },
  TANGELA = { dex = 114, spa = 100, spd = 40 },
  KANGASKHAN = { dex = 115, spa = 40, spd = 80 },
  HORSEA = { dex = 116, spa = 70, spd = 25 },
  SEADRA = { dex = 117, spa = 95, spd = 45 },
  GOLDEEN = { dex = 118, spa = 35, spd = 50 },
  SEAKING = { dex = 119, spa = 65, spd = 80 },
  STARYU = { dex = 120, spa = 70, spd = 55 },
  STARMIE = { dex = 121, spa = 100, spd = 85 },
  MR_MIME = { dex = 122, spa = 100, spd = 120 },
  SCYTHER = { dex = 123, spa = 55, spd = 80 },
  JYNX = { dex = 124, spa = 115, spd = 95 },
  ELECTABUZZ = { dex = 125, spa = 95, spd = 85 },
  MAGMAR = { dex = 126, spa = 100, spd = 85 },
  PINSIR = { dex = 127, spa = 55, spd = 70 },
  TAUROS = { dex = 128, spa = 40, spd = 70 },
  MAGIKARP = { dex = 129, spa = 15, spd = 20 },
  GYARADOS = { dex = 130, spa = 60, spd = 100 },
  LAPRAS = { dex = 131, spa = 85, spd = 95 },
  DITTO = { dex = 132, spa = 48, spd = 48 },
  EEVEE = { dex = 133, spa = 45, spd = 65 },
  VAPOREON = { dex = 134, spa = 110, spd = 95 },
  JOLTEON = { dex = 135, spa = 110, spd = 95 },
  FLAREON = { dex = 136, spa = 95, spd = 110 },
  PORYGON = { dex = 137, spa = 85, spd = 75 },
  OMANYTE = { dex = 138, spa = 90, spd = 55 },
  OMASTAR = { dex = 139, spa = 115, spd = 70 },
  KABUTO = { dex = 140, spa = 55, spd = 45 },
  KABUTOPS = { dex = 141, spa = 65, spd = 70 },
  AERODACTYL = { dex = 142, spa = 60, spd = 75 },
  SNORLAX = { dex = 143, spa = 65, spd = 110 },
  ARTICUNO = { dex = 144, spa = 95, spd = 125 },
  ZAPDOS = { dex = 145, spa = 125, spd = 90 },
  MOLTRES = { dex = 146, spa = 125, spd = 85 },
  DRATINI = { dex = 147, spa = 50, spd = 50 },
  DRAGONAIR = { dex = 148, spa = 70, spd = 70 },
  DRAGONITE = { dex = 149, spa = 100, spd = 100 },
  MEWTWO = { dex = 150, spa = 154, spd = 90 },
  MEW = { dex = 151, spa = 100, spd = 100 },
  CHIKORITA = { dex = 152, spa = 49, spd = 65 },
  BAYLEEF = { dex = 153, spa = 63, spd = 80 },
  MEGANIUM = { dex = 154, spa = 83, spd = 100 },
  CYNDAQUIL = { dex = 155, spa = 60, spd = 50 },
  QUILAVA = { dex = 156, spa = 80, spd = 65 },
  TYPHLOSION = { dex = 157, spa = 109, spd = 85 },
  TOTODILE = { dex = 158, spa = 44, spd = 48 },
  CROCONAW = { dex = 159, spa = 59, spd = 63 },
  FERALIGATR = { dex = 160, spa = 79, spd = 83 },
  SENTRET = { dex = 161, spa = 35, spd = 45 },
  FURRET = { dex = 162, spa = 45, spd = 55 },
  HOOTHOOT = { dex = 163, spa = 36, spd = 56 },
  NOCTOWL = { dex = 164, spa = 76, spd = 96 },
  LEDYBA = { dex = 165, spa = 40, spd = 80 },
  LEDIAN = { dex = 166, spa = 55, spd = 110 },
  SPINARAK = { dex = 167, spa = 40, spd = 40 },
  ARIADOS = { dex = 168, spa = 60, spd = 60 },
  CROBAT = { dex = 169, spa = 70, spd = 80 },
  CHINCHOU = { dex = 170, spa = 56, spd = 56 },
  LANTURN = { dex = 171, spa = 76, spd = 76 },
  PICHU = { dex = 172, spa = 35, spd = 35 },
  CLEFFA = { dex = 173, spa = 45, spd = 55 },
  IGGLYBUFF = { dex = 174, spa = 40, spd = 20 },
  TOGEPI = { dex = 175, spa = 40, spd = 65 },
  TOGETIC = { dex = 176, spa = 80, spd = 105 },
  NATU = { dex = 177, spa = 70, spd = 45 },
  XATU = { dex = 178, spa = 95, spd = 70 },
  MAREEP = { dex = 179, spa = 65, spd = 45 },
  FLAAFFY = { dex = 180, spa = 80, spd = 60 },
  AMPHAROS = { dex = 181, spa = 115, spd = 90 },
  BELLOSSOM = { dex = 182, spa = 90, spd = 100 },
  MARILL = { dex = 183, spa = 20, spd = 50 },
  AZUMARILL = { dex = 184, spa = 50, spd = 80 },
  SUDOWOODO = { dex = 185, spa = 30, spd = 65 },
  POLITOED = { dex = 186, spa = 90, spd = 100 },
  HOPPIP = { dex = 187, spa = 35, spd = 55 },
  SKIPLOOM = { dex = 188, spa = 45, spd = 65 },
  JUMPLUFF = { dex = 189, spa = 55, spd = 85 },
  AIPOM = { dex = 190, spa = 40, spd = 55 },
  SUNKERN = { dex = 191, spa = 30, spd = 30 },
  SUNFLORA = { dex = 192, spa = 105, spd = 85 },
  YANMA = { dex = 193, spa = 75, spd = 45 },
  WOOPER = { dex = 194, spa = 25, spd = 25 },
  QUAGSIRE = { dex = 195, spa = 65, spd = 65 },
  ESPEON = { dex = 196, spa = 130, spd = 95 },
  UMBREON = { dex = 197, spa = 60, spd = 130 },
  MURKROW = { dex = 198, spa = 85, spd = 42 },
  SLOWKING = { dex = 199, spa = 100, spd = 110 },
  MISDREAVUS = { dex = 200, spa = 85, spd = 85 },
  UNOWN = { dex = 201, spa = 72, spd = 48 },
  WOBBUFFET = { dex = 202, spa = 33, spd = 58 },
  GIRAFARIG = { dex = 203, spa = 90, spd = 65 },
  PINECO = { dex = 204, spa = 35, spd = 35 },
  FORRETRESS = { dex = 205, spa = 60, spd = 60 },
  DUNSPARCE = { dex = 206, spa = 65, spd = 65 },
  GLIGAR = { dex = 207, spa = 35, spd = 65 },
  STEELIX = { dex = 208, spa = 55, spd = 65 },
  SNUBBULL = { dex = 209, spa = 40, spd = 40 },
  GRANBULL = { dex = 210, spa = 60, spd = 60 },
  QWILFISH = { dex = 211, spa = 55, spd = 55 },
  SCIZOR = { dex = 212, spa = 55, spd = 80 },
  SHUCKLE = { dex = 213, spa = 10, spd = 230 },
  HERACROSS = { dex = 214, spa = 40, spd = 95 },
  SNEASEL = { dex = 215, spa = 35, spd = 75 },
  TEDDIURSA = { dex = 216, spa = 50, spd = 50 },
  URSARING = { dex = 217, spa = 75, spd = 75 },
  SLUGMA = { dex = 218, spa = 70, spd = 40 },
  MAGCARGO = { dex = 219, spa = 80, spd = 80 },
  SWINUB = { dex = 220, spa = 30, spd = 30 },
  PILOSWINE = { dex = 221, spa = 60, spd = 60 },
  CORSOLA = { dex = 222, spa = 65, spd = 85 },
  REMORAID = { dex = 223, spa = 65, spd = 35 },
  OCTILLERY = { dex = 224, spa = 105, spd = 75 },
  DELIBIRD = { dex = 225, spa = 65, spd = 45 },
  MANTINE = { dex = 226, spa = 80, spd = 140 },
  SKARMORY = { dex = 227, spa = 40, spd = 70 },
  HOUNDOUR = { dex = 228, spa = 80, spd = 50 },
  HOUNDOOM = { dex = 229, spa = 110, spd = 80 },
  KINGDRA = { dex = 230, spa = 95, spd = 95 },
  PHANPY = { dex = 231, spa = 40, spd = 40 },
  DONPHAN = { dex = 232, spa = 60, spd = 60 },
  PORYGON2 = { dex = 233, spa = 105, spd = 95 },
  STANTLER = { dex = 234, spa = 85, spd = 65 },
  SMEARGLE = { dex = 235, spa = 20, spd = 45 },
  TYROGUE = { dex = 236, spa = 35, spd = 35 },
  HITMONTOP = { dex = 237, spa = 35, spd = 110 },
  SMOOCHUM = { dex = 238, spa = 85, spd = 65 },
  ELEKID = { dex = 239, spa = 65, spd = 55 },
  MAGBY = { dex = 240, spa = 70, spd = 55 },
  MILTANK = { dex = 241, spa = 40, spd = 70 },
  BLISSEY = { dex = 242, spa = 75, spd = 135 },
  RAIKOU = { dex = 243, spa = 115, spd = 100 },
  ENTEI = { dex = 244, spa = 90, spd = 75 },
  SUICUNE = { dex = 245, spa = 90, spd = 115 },
  LARVITAR = { dex = 246, spa = 45, spd = 50 },
  PUPITAR = { dex = 247, spa = 65, spd = 70 },
  TYRANITAR = { dex = 248, spa = 95, spd = 100 },
  LUGIA = { dex = 249, spa = 90, spd = 154 },
  HO_OH = { dex = 250, spa = 110, spd = 154 },
  CELEBI = { dex = 251, spa = 100, spd = 100 },
}
local GEN2_SPECIAL_BY_DEX = {}
for _, row in pairs(GEN2_SPECIAL_BY_ID) do GEN2_SPECIAL_BY_DEX[row.dex] = row end

local GEN4_MOVE_CATEGORY_BY_INDEX = {
  [1] = "physical", -- pound
  [2] = "physical", -- karate-chop
  [3] = "physical", -- double-slap
  [4] = "physical", -- comet-punch
  [5] = "physical", -- mega-punch
  [6] = "physical", -- pay-day
  [7] = "physical", -- fire-punch
  [8] = "physical", -- ice-punch
  [9] = "physical", -- thunder-punch
  [10] = "physical", -- scratch
  [11] = "physical", -- vice-grip
  [12] = "physical", -- guillotine
  [13] = "special", -- razor-wind
  [14] = "status", -- swords-dance
  [15] = "physical", -- cut
  [16] = "special", -- gust
  [17] = "physical", -- wing-attack
  [18] = "status", -- whirlwind
  [19] = "physical", -- fly
  [20] = "physical", -- bind
  [21] = "physical", -- slam
  [22] = "physical", -- vine-whip
  [23] = "physical", -- stomp
  [24] = "physical", -- double-kick
  [25] = "physical", -- mega-kick
  [26] = "physical", -- jump-kick
  [27] = "physical", -- rolling-kick
  [28] = "status", -- sand-attack
  [29] = "physical", -- headbutt
  [30] = "physical", -- horn-attack
  [31] = "physical", -- fury-attack
  [32] = "physical", -- horn-drill
  [33] = "physical", -- tackle
  [34] = "physical", -- body-slam
  [35] = "physical", -- wrap
  [36] = "physical", -- take-down
  [37] = "physical", -- thrash
  [38] = "physical", -- double-edge
  [39] = "status", -- tail-whip
  [40] = "physical", -- poison-sting
  [41] = "physical", -- twineedle
  [42] = "physical", -- pin-missile
  [43] = "status", -- leer
  [44] = "physical", -- bite
  [45] = "status", -- growl
  [46] = "status", -- roar
  [47] = "status", -- sing
  [48] = "status", -- supersonic
  [49] = "special", -- sonic-boom
  [50] = "status", -- disable
  [51] = "special", -- acid
  [52] = "special", -- ember
  [53] = "special", -- flamethrower
  [54] = "status", -- mist
  [55] = "special", -- water-gun
  [56] = "special", -- hydro-pump
  [57] = "special", -- surf
  [58] = "special", -- ice-beam
  [59] = "special", -- blizzard
  [60] = "special", -- psybeam
  [61] = "special", -- bubble-beam
  [62] = "special", -- aurora-beam
  [63] = "special", -- hyper-beam
  [64] = "physical", -- peck
  [65] = "physical", -- drill-peck
  [66] = "physical", -- submission
  [67] = "physical", -- low-kick
  [68] = "physical", -- counter
  [69] = "physical", -- seismic-toss
  [70] = "physical", -- strength
  [71] = "special", -- absorb
  [72] = "special", -- mega-drain
  [73] = "status", -- leech-seed
  [74] = "status", -- growth
  [75] = "physical", -- razor-leaf
  [76] = "special", -- solar-beam
  [77] = "status", -- poison-powder
  [78] = "status", -- stun-spore
  [79] = "status", -- sleep-powder
  [80] = "special", -- petal-dance
  [81] = "status", -- string-shot
  [82] = "special", -- dragon-rage
  [83] = "special", -- fire-spin
  [84] = "special", -- thunder-shock
  [85] = "special", -- thunderbolt
  [86] = "status", -- thunder-wave
  [87] = "special", -- thunder
  [88] = "physical", -- rock-throw
  [89] = "physical", -- earthquake
  [90] = "physical", -- fissure
  [91] = "physical", -- dig
  [92] = "status", -- toxic
  [93] = "special", -- confusion
  [94] = "special", -- psychic
  [95] = "status", -- hypnosis
  [96] = "status", -- meditate
  [97] = "status", -- agility
  [98] = "physical", -- quick-attack
  [99] = "physical", -- rage
  [100] = "status", -- teleport
  [101] = "special", -- night-shade
  [102] = "status", -- mimic
  [103] = "status", -- screech
  [104] = "status", -- double-team
  [105] = "status", -- recover
  [106] = "status", -- harden
  [107] = "status", -- minimize
  [108] = "status", -- smokescreen
  [109] = "status", -- confuse-ray
  [110] = "status", -- withdraw
  [111] = "status", -- defense-curl
  [112] = "status", -- barrier
  [113] = "status", -- light-screen
  [114] = "status", -- haze
  [115] = "status", -- reflect
  [116] = "status", -- focus-energy
  [117] = "physical", -- bide
  [118] = "status", -- metronome
  [119] = "status", -- mirror-move
  [120] = "physical", -- self-destruct
  [121] = "physical", -- egg-bomb
  [122] = "physical", -- lick
  [123] = "special", -- smog
  [124] = "special", -- sludge
  [125] = "physical", -- bone-club
  [126] = "special", -- fire-blast
  [127] = "physical", -- waterfall
  [128] = "physical", -- clamp
  [129] = "special", -- swift
  [130] = "physical", -- skull-bash
  [131] = "physical", -- spike-cannon
  [132] = "physical", -- constrict
  [133] = "status", -- amnesia
  [134] = "status", -- kinesis
  [135] = "status", -- soft-boiled
  [136] = "physical", -- high-jump-kick
  [137] = "status", -- glare
  [138] = "special", -- dream-eater
  [139] = "status", -- poison-gas
  [140] = "physical", -- barrage
  [141] = "physical", -- leech-life
  [142] = "status", -- lovely-kiss
  [143] = "physical", -- sky-attack
  [144] = "status", -- transform
  [145] = "special", -- bubble
  [146] = "physical", -- dizzy-punch
  [147] = "status", -- spore
  [148] = "status", -- flash
  [149] = "special", -- psywave
  [150] = "status", -- splash
  [151] = "status", -- acid-armor
  [152] = "physical", -- crabhammer
  [153] = "physical", -- explosion
  [154] = "physical", -- fury-swipes
  [155] = "physical", -- bonemerang
  [156] = "status", -- rest
  [157] = "physical", -- rock-slide
  [158] = "physical", -- hyper-fang
  [159] = "status", -- sharpen
  [160] = "status", -- conversion
  [161] = "special", -- tri-attack
  [162] = "physical", -- super-fang
  [163] = "physical", -- slash
  [164] = "status", -- substitute
  [165] = "physical", -- struggle
  [166] = "status", -- sketch
  [167] = "physical", -- triple-kick
  [168] = "physical", -- thief
  [169] = "status", -- spider-web
  [170] = "status", -- mind-reader
  [171] = "status", -- nightmare
  [172] = "physical", -- flame-wheel
  [173] = "special", -- snore
  [174] = "status", -- curse
  [175] = "physical", -- flail
  [176] = "status", -- conversion-2
  [177] = "special", -- aeroblast
  [178] = "status", -- cotton-spore
  [179] = "physical", -- reversal
  [180] = "status", -- spite
  [181] = "special", -- powder-snow
  [182] = "status", -- protect
  [183] = "physical", -- mach-punch
  [184] = "status", -- scary-face
  [185] = "physical", -- feint-attack
  [186] = "status", -- sweet-kiss
  [187] = "status", -- belly-drum
  [188] = "special", -- sludge-bomb
  [189] = "special", -- mud-slap
  [190] = "special", -- octazooka
  [191] = "status", -- spikes
  [192] = "special", -- zap-cannon
  [193] = "status", -- foresight
  [194] = "status", -- destiny-bond
  [195] = "status", -- perish-song
  [196] = "special", -- icy-wind
  [197] = "status", -- detect
  [198] = "physical", -- bone-rush
  [199] = "status", -- lock-on
  [200] = "physical", -- outrage
  [201] = "status", -- sandstorm
  [202] = "special", -- giga-drain
  [203] = "status", -- endure
  [204] = "status", -- charm
  [205] = "physical", -- rollout
  [206] = "physical", -- false-swipe
  [207] = "status", -- swagger
  [208] = "status", -- milk-drink
  [209] = "physical", -- spark
  [210] = "physical", -- fury-cutter
  [211] = "physical", -- steel-wing
  [212] = "status", -- mean-look
  [213] = "status", -- attract
  [214] = "status", -- sleep-talk
  [215] = "status", -- heal-bell
  [216] = "physical", -- return
  [217] = "physical", -- present
  [218] = "physical", -- frustration
  [219] = "status", -- safeguard
  [220] = "status", -- pain-split
  [221] = "physical", -- sacred-fire
  [222] = "physical", -- magnitude
  [223] = "physical", -- dynamic-punch
  [224] = "physical", -- megahorn
  [225] = "special", -- dragon-breath
  [226] = "status", -- baton-pass
  [227] = "status", -- encore
  [228] = "physical", -- pursuit
  [229] = "physical", -- rapid-spin
  [230] = "status", -- sweet-scent
  [231] = "physical", -- iron-tail
  [232] = "physical", -- metal-claw
  [233] = "physical", -- vital-throw
  [234] = "status", -- morning-sun
  [235] = "status", -- synthesis
  [236] = "status", -- moonlight
  [237] = "special", -- hidden-power
  [238] = "physical", -- cross-chop
  [239] = "special", -- twister
  [240] = "status", -- rain-dance
  [241] = "status", -- sunny-day
  [242] = "physical", -- crunch
  [243] = "special", -- mirror-coat
  [244] = "status", -- psych-up
  [245] = "physical", -- extreme-speed
  [246] = "special", -- ancient-power
  [247] = "special", -- shadow-ball
  [248] = "special", -- future-sight
  [249] = "physical", -- rock-smash
  [250] = "special", -- whirlpool
  [251] = "physical", -- beat-up
}

local GEN1_MOVE_KEY_BY_INDEX = {
  [1] = "POUND",
  [2] = "KARATE_CHOP",
  [3] = "DOUBLESLAP",
  [4] = "COMET_PUNCH",
  [5] = "MEGA_PUNCH",
  [6] = "PAY_DAY",
  [7] = "FIRE_PUNCH",
  [8] = "ICE_PUNCH",
  [9] = "THUNDERPUNCH",
  [10] = "SCRATCH",
  [11] = "VICEGRIP",
  [12] = "GUILLOTINE",
  [13] = "RAZOR_WIND",
  [14] = "SWORDS_DANCE",
  [15] = "CUT",
  [16] = "GUST",
  [17] = "WING_ATTACK",
  [18] = "WHIRLWIND",
  [19] = "FLY",
  [20] = "BIND",
  [21] = "SLAM",
  [22] = "VINE_WHIP",
  [23] = "STOMP",
  [24] = "DOUBLE_KICK",
  [25] = "MEGA_KICK",
  [26] = "JUMP_KICK",
  [27] = "ROLLING_KICK",
  [28] = "SAND_ATTACK",
  [29] = "HEADBUTT",
  [30] = "HORN_ATTACK",
  [31] = "FURY_ATTACK",
  [32] = "HORN_DRILL",
  [33] = "TACKLE",
  [34] = "BODY_SLAM",
  [35] = "WRAP",
  [36] = "TAKE_DOWN",
  [37] = "THRASH",
  [38] = "DOUBLE_EDGE",
  [39] = "TAIL_WHIP",
  [40] = "POISON_STING",
  [41] = "TWINEEDLE",
  [42] = "PIN_MISSILE",
  [43] = "LEER",
  [44] = "BITE",
  [45] = "GROWL",
  [46] = "ROAR",
  [47] = "SING",
  [48] = "SUPERSONIC",
  [49] = "SONICBOOM",
  [50] = "DISABLE",
  [51] = "ACID",
  [52] = "EMBER",
  [53] = "FLAMETHROWER",
  [54] = "MIST",
  [55] = "WATER_GUN",
  [56] = "HYDRO_PUMP",
  [57] = "SURF",
  [58] = "ICE_BEAM",
  [59] = "BLIZZARD",
  [60] = "PSYBEAM",
  [61] = "BUBBLEBEAM",
  [62] = "AURORA_BEAM",
  [63] = "HYPER_BEAM",
  [64] = "PECK",
  [65] = "DRILL_PECK",
  [66] = "SUBMISSION",
  [67] = "LOW_KICK",
  [68] = "COUNTER",
  [69] = "SEISMIC_TOSS",
  [70] = "STRENGTH",
  [71] = "ABSORB",
  [72] = "MEGA_DRAIN",
  [73] = "LEECH_SEED",
  [74] = "GROWTH",
  [75] = "RAZOR_LEAF",
  [76] = "SOLARBEAM",
  [77] = "POISONPOWDER",
  [78] = "STUN_SPORE",
  [79] = "SLEEP_POWDER",
  [80] = "PETAL_DANCE",
  [81] = "STRING_SHOT",
  [82] = "DRAGON_RAGE",
  [83] = "FIRE_SPIN",
  [84] = "THUNDERSHOCK",
  [85] = "THUNDERBOLT",
  [86] = "THUNDER_WAVE",
  [87] = "THUNDER",
  [88] = "ROCK_THROW",
  [89] = "EARTHQUAKE",
  [90] = "FISSURE",
  [91] = "DIG",
  [92] = "TOXIC",
  [93] = "CONFUSION",
  [94] = "PSYCHIC_M",
  [95] = "HYPNOSIS",
  [96] = "MEDITATE",
  [97] = "AGILITY",
  [98] = "QUICK_ATTACK",
  [99] = "RAGE",
  [100] = "TELEPORT",
  [101] = "NIGHT_SHADE",
  [102] = "MIMIC",
  [103] = "SCREECH",
  [104] = "DOUBLE_TEAM",
  [105] = "RECOVER",
  [106] = "HARDEN",
  [107] = "MINIMIZE",
  [108] = "SMOKESCREEN",
  [109] = "CONFUSE_RAY",
  [110] = "WITHDRAW",
  [111] = "DEFENSE_CURL",
  [112] = "BARRIER",
  [113] = "LIGHT_SCREEN",
  [114] = "HAZE",
  [115] = "REFLECT",
  [116] = "FOCUS_ENERGY",
  [117] = "BIDE",
  [118] = "METRONOME",
  [119] = "MIRROR_MOVE",
  [120] = "SELFDESTRUCT",
  [121] = "EGG_BOMB",
  [122] = "LICK",
  [123] = "SMOG",
  [124] = "SLUDGE",
  [125] = "BONE_CLUB",
  [126] = "FIRE_BLAST",
  [127] = "WATERFALL",
  [128] = "CLAMP",
  [129] = "SWIFT",
  [130] = "SKULL_BASH",
  [131] = "SPIKE_CANNON",
  [132] = "CONSTRICT",
  [133] = "AMNESIA",
  [134] = "KINESIS",
  [135] = "SOFTBOILED",
  [136] = "HI_JUMP_KICK",
  [137] = "GLARE",
  [138] = "DREAM_EATER",
  [139] = "POISON_GAS",
  [140] = "BARRAGE",
  [141] = "LEECH_LIFE",
  [142] = "LOVELY_KISS",
  [143] = "SKY_ATTACK",
  [144] = "TRANSFORM",
  [145] = "BUBBLE",
  [146] = "DIZZY_PUNCH",
  [147] = "SPORE",
  [148] = "FLASH",
  [149] = "PSYWAVE",
  [150] = "SPLASH",
  [151] = "ACID_ARMOR",
  [152] = "CRABHAMMER",
  [153] = "EXPLOSION",
  [154] = "FURY_SWIPES",
  [155] = "BONEMERANG",
  [156] = "REST",
  [157] = "ROCK_SLIDE",
  [158] = "HYPER_FANG",
  [159] = "SHARPEN",
  [160] = "CONVERSION",
  [161] = "TRI_ATTACK",
  [162] = "SUPER_FANG",
  [163] = "SLASH",
  [164] = "SUBSTITUTE",
  [165] = "STRUGGLE",
}
local function normalizeMoveKey(value)
  return tostring(value or ""):lower():gsub("[^%w]", "")
end

local function isCanonicalGen1Move(id, move, index)
  local expected = GEN1_MOVE_KEY_BY_INDEX[index]
  if not expected or type(move) ~= "table" then return false end
  local want = normalizeMoveKey(expected)
  return normalizeMoveKey(id) == want
      or normalizeMoveKey(move.id) == want
      or normalizeMoveKey(move.name) == want
end

local SplitStats = {}
local CRYSTAL_SPECIAL_BY_ID = nil

function SplitStats.setCrystalBaseStats(baseStats)
  if type(baseStats) ~= "table" then
    CRYSTAL_SPECIAL_BY_ID = nil
    return 0
  end
  local out, count = {}, 0
  for id, row in pairs(baseStats) do
    if type(row) == "table" then
      local spa = tonumber(row.specialAttack)
      local spd = tonumber(row.specialDefense)
      if spa and spd then
        out[id] = { spa = spa, spd = spd }
        count = count + 1
      end
    end
  end
  CRYSTAL_SPECIAL_BY_ID = out
  return count
end

local function calcSplitStat(base, dv, statExp, level)
  local ev = math.floor(math.min(255, math.ceil(math.sqrt(statExp or 0))) / 4)
  return math.floor(((base + (dv or 0)) * 2 + ev) * level / 100) + 5
end
SplitStats.calcOne = calcSplitStat
function SplitStats.baseFor(speciesDef)
  if type(speciesDef) ~= "table" then return nil end
  -- The mod-owned Gen II-V table is authoritative for National Dex #001-251.
  -- This avoids silently collapsing Johto back to one legacy SPECIAL value if
  -- Crystal's optional cross-mod export is unavailable at runtime.
  local row = speciesDef.id and GEN2_SPECIAL_BY_ID[speciesDef.id] or nil
  if not row and speciesDef.dex then row = GEN2_SPECIAL_BY_DEX[speciesDef.dex] end
  -- Crystal remains a last-resort fallback for content outside our canonical
  -- table, never an override for #001-251.
  if not row then
    row = speciesDef.id and CRYSTAL_SPECIAL_BY_ID
      and CRYSTAL_SPECIAL_BY_ID[speciesDef.id] or nil
  end
  return row
end
function SplitStats.calculate(speciesDef, level, dvs, statExp, vanillaSpecial)
  local row = SplitStats.baseFor(speciesDef)
  if not row then return vanillaSpecial, vanillaSpecial end
  dvs = dvs or {}
  statExp = statExp or {}
  local dv = dvs.special or 0
  local exp = statExp.special or 0
  return calcSplitStat(row.spa, dv, exp, level), calcSplitStat(row.spd, dv, exp, level)
end
function SplitStats.attach(stats, speciesDef, level, dvs, statExp)
  if type(stats) ~= "table" then return stats end
  local spa, spd = SplitStats.calculate(speciesDef, level, dvs, statExp, stats.special)
  stats.specialAttack = spa
  stats.specialDefense = spd
  return stats
end

return function(mod)
  local Stats = require("src.pokemon.Stats")
  local Damage = require("src.battle.Damage")
  local Experience = require("src.battle.Experience")
  local ItemEffects = require("src.inventory.ItemEffects")
  local MoveEffects = require("src.battle.MoveEffects")
  local SummaryMenu = require("src.ui.SummaryMenu")
  local BattleState = require("src.battle.BattleState")
  local Font = require("src.render.Font")
  local Strings = require("src.core.Strings")
  local SaveData = require("src.core.SaveData")

  -- Optional Crystal 251 compatibility. Crystal's move runtime table is used
  -- for its battle bridge. Its split-stat export is captured only as a
  -- last-resort fallback/diagnostic source: canonical #001-251 SpA/SpD always
  -- come from this mod's own audited Generation II-V table.
  local crystalMod = type(mod.find) == "function" and mod.find("CRYSTAL_251") or nil
  local crystalExports = crystalMod and crystalMod.exports or nil
  local crystalBaseStats = crystalExports and crystalExports.crystalBaseStats or nil
  local crystalMoves = crystalExports and crystalExports.crystalMoves or nil
  local crystalStatCount = SplitStats.setCrystalBaseStats(crystalBaseStats)
  if crystalStatCount > 0 and mod.log and type(mod.log.info) == "function" then
    mod.log:info(("Crystal 251 split-stat export detected (%d records); canonical mod-owned #001-251 table has priority")
      :format(crystalStatCount))
  end

  mod.options:define({
    {
      key = "mode",
      label = "SPECIAL STATS (RESTART)",
      type = "choice",
      default = "gen2",
      choices = {
        { "VANILLA", "vanilla" },
        { "GEN II (SP. ATK / SP. DEF)", "gen2" },
      },
    },
    {
      key = "move_split",
      label = "MOVE CATEGORIES (RESTART)",
      type = "choice",
      default = "gen4",
      choices = {
        { "GEN I (BY TYPE)", "gen1" },
        { "GEN IV+ (BY MOVE)", "gen4" },
      },
    },
    {
      key = "move_category_readout",
      label = "MOVE CATEGORY READOUT",
      type = "toggle",
      default = true,
      description = "Show PHYS/ or SPEC/ instead of TYPE/ for damaging moves in the battle move-select box. Status/fixed-damage moves keep TYPE/.",
    },
    {
      key = "modern_ui_override",
      label = "ModernUI Override",
      type = "toggle",
      default = true,
      description = "Surgically replace only Modern UI's legacy SPECIAL stat text on supported Party/Summary renderers while preserving Modern UI's own layout, sprites, bars, icons and styling. OFF leaves Modern UI completely untouched.",
    },
    {
      key = "modern_ui_battle_wip_override",
      label = "ModernUI BattleWIP Override",
      type = "toggle",
      default = false,
      description = "Opt in to compatibility overrides for Gen1 Modern UI's experimental Battle UI (WIP), including battle Party split-stat presentation and the level-up correction card. OFF leaves the experimental battle presentation untouched.",
    },
  })

  -- Capture the two gameplay modes once at load time: changing either requires save + restart.
  -- Both ModernUI compatibility toggles are presentation-only and are read live.
  local active = tostring(mod.options:get("mode") or "gen2") == "gen2"
  local moveSplitActive = tostring(mod.options:get("move_split") or "gen4") == "gen4"

  -- Integrated Move Category Readout (formerly the standalone move_category mod).
  -- This is presentation-only and live-toggleable: it replaces BattleState's
  -- otherwise redundant TYPE/ label with PHYS/ or SPEC/ for damaging moves.
  -- Category resolution mirrors Damage.categoryOf: explicit move.category first,
  -- then the active type chart. Power-0/status/fixed-damage moves keep TYPE/.
  --
  -- Coexistence with the old standalone mod is intentionally composable. The
  -- standalone mod is an optional dependency, so when it is active it loads
  -- first. Both wrappers only transform the exact TYPE/ token. Whichever wrapper
  -- transforms it first passes PHYS/ or SPEC/ downstream, which the other wrapper
  -- ignores; therefore two installed copies never draw twice or raise a conflict.
  -- If either mod's readout toggle is ON, the readout is visible; if both are OFF,
  -- vanilla TYPE/ is preserved.
  do
    local LABELS = { physical = "PHYS/", special = "SPEC/" }
    local TYPE_LABEL = Strings("TYPE/")
    local TypeChart = require("src.battle.TypeChart")
    local readout = rawget(Font, MOVE_READOUT_PATCH_KEY)

    if not readout then
      readout = {
        originalDraw = Font.draw,
        currentBattle = nil,
        typeLabel = TYPE_LABEL,
        categoryLabel = nil,
      }
      rawset(Font, MOVE_READOUT_PATCH_KEY, readout)

      Font.draw = function(text, x, y, ...)
        if text == readout.typeLabel and type(readout.categoryLabel) == "function" then
          text = readout.categoryLabel(readout.currentBattle) or text
        end
        return readout.originalDraw(text, x, y, ...)
      end
    end

    -- Hot reload updates behavior/state without stacking another Font.draw wrapper.
    readout.typeLabel = TYPE_LABEL
    readout.categoryLabel = function(battle)
      if mod.options:get("move_category_readout") == false then return nil end
      if not battle or battle.phase ~= "moveSelect" then return nil end

      local moves = battle.player and battle.player.curMoves
      local selected = moves and moves[battle.moveIndex]
      if not selected then return nil end

      local def = battle.data and battle.data.moves and battle.data.moves[selected.id]
      if not def then return nil end
      if (def.power or 0) == 0 or def.category == "status" then return nil end

      local category = def.category or (def.type and TypeChart.category(def.type))
      return LABELS[category] or LABELS.physical
    end

    if mod.events and type(mod.events.on) == "function" then
      mod.events:on("battle.started", function(payload)
        readout.currentBattle = payload and payload.battle or nil
      end)
      mod.events:on("battle.ended", function()
        readout.currentBattle = nil
      end)
    end

    local standalone = type(mod.find) == "function" and mod.find("move_category") or nil
    if standalone and mod.log and type(mod.log.info) == "function" then
      mod.log:info("Standalone Move Category Readout detected; integrated readout composes without duplicate output")
    end

    mod.exports.moveCategoryReadoutEnabled = function()
      return mod.options:get("move_category_readout") ~= false
    end
  end

  -- Generation IV introduced per-move damage categories. The standalone
  -- Gen I pool is still handled exactly as before (165 canonical moves). When
  -- Crystal 251 is present, the same audited table extends through move index
  -- 251 so every Generation II move receives its modern per-move category.
  --
  -- For Gen I records we retain the exact identity guard. For Crystal's new
  -- records, identity is validated against Crystal's own exported move table,
  -- avoiding accidental category assignment to an unrelated custom move that
  -- merely reuses an index in the 166..251 range.
  local function isCanonicalMergedMove(id, move, index)
    if index and index <= 165 then
      return isCanonicalGen1Move(id, move, index)
    end
    if not (index and index >= 166 and index <= 251
        and type(crystalMoves) == "table") then
      return false
    end
    local row = crystalMoves[id]
    return type(row) == "table" and tonumber(row.index) == index
  end

  -- Crystal keeps a private runtime copy of all 251 moves. Update that table
  -- too, otherwise reactive effects and Crystal's AI could observe the old
  -- Generation II category even while the merged registry says GEN IV+.
  if moveSplitActive and type(crystalMoves) == "table" then
    local runtimeChanged = 0
    for _, row in pairs(crystalMoves) do
      local index = type(row) == "table" and tonumber(row.index) or nil
      local category = index and GEN4_MOVE_CATEGORY_BY_INDEX[index] or nil
      if category then
        row.category = category
        runtimeChanged = runtimeChanged + 1
      end
    end
    if mod.log and type(mod.log.info) == "function" then
      mod.log:info(("Crystal 251 runtime categories updated: %d canonical moves")
        :format(runtimeChanged))
    end
  end

  if mod.content and mod.content.moves
      and type(mod.content.moves.each) == "function"
      and type(mod.content.moves.patch) == "function" then
    local changed, preexistingConflicts, identitySkips = 0, 0, 0
    for id, move in mod.content.moves:each() do
      local index = type(move) == "table" and tonumber(move.index) or nil
      local category = index and GEN4_MOVE_CATEGORY_BY_INDEX[index] or nil
      if category then
        if isCanonicalMergedMove(id, move, index) then
          if moveSplitActive then
            if move.category ~= nil and move.category ~= category then
              preexistingConflicts = preexistingConflicts + 1
            end
            mod.content.moves:patch(id, { category = category })
            changed = changed + 1
          elseif index <= 165 and mod.DELETE ~= nil then
            -- Preserve the historical standalone behavior: GEN I mode clears
            -- explicit categories on the original 165 moves. Crystal's new
            -- Gen II move records are already type-based and are left intact.
            if move.category ~= nil then preexistingConflicts = preexistingConflicts + 1 end
            mod.content.moves:patch(id, { category = mod.DELETE })
            changed = changed + 1
          elseif index <= 165 and move.category ~= nil
              and mod.log and type(mod.log.warn) == "function" then
            mod.log:warn("GEN I move-category mode could not clear explicit category: mod.DELETE unavailable")
          end
        else
          identitySkips = identitySkips + 1
        end
      end
    end
    if mod.log and type(mod.log.info) == "function" then
      if moveSplitActive then
        local scope = type(crystalMoves) == "table" and "Gen I+II" or "Gen I"
        mod.log:info(("GEN IV+ move split enabled: categorized %d canonical %s moves; %d preexisting category conflicts overridden; %d index/identity collisions skipped")
          :format(changed, scope, preexistingConflicts, identitySkips))
      else
        mod.log:info(("GEN I move-category mode enabled: cleared explicit category on %d canonical Gen I moves; %d preexisting categories removed; %d index/identity collisions skipped")
          :format(changed, preexistingConflicts, identitySkips))
      end
    end
  end

  -- Crystal's Generation II damage module normally derives the damage class
  -- from elemental type, ignoring move.category. In GEN IV+ mode we bridge that
  -- one internal decision without replacing Crystal's damage formula:
  --  * prepareMove is allowed to seed Crystal's row, then we restore the modern
  --    explicit category from the 1..251 table;
  --  * compute temporarily changes Crystal's private physical-type lookup for
  --    this synchronous calculation only, so its existing categoryOf() chooses
  --    the requested Physical/Special side while move.type itself remains
  --    untouched for STAB, weather, held-item boosts and effectiveness.
  --
  -- This intentionally uses engine_internals/debug only when Crystal is present.
  -- Standalone behavior takes the exact pre-2.2.0 path.
  do
    local CrystalDamage = nil
    if type(crystalMoves) == "table" then
      local ok, value = pcall(require, "mods.CRYSTAL_251.battle.crystal_damage")
      if ok and type(value) == "table" then CrystalDamage = value end
    end

    if CrystalDamage and type(CrystalDamage.prepareMove) == "function"
        and type(CrystalDamage.compute) == "function" then
      local BRIDGE_KEY = "__special_stat_split_crystal_damage_bridge_v1"
      local bridge = rawget(CrystalDamage, BRIDGE_KEY)

      if not bridge then
        local physicalTypes = nil
        if type(debug) == "table" and type(debug.getupvalue) == "function" then
          for i = 1, 64 do
            local name, value = debug.getupvalue(CrystalDamage.prepareMove, i)
            if not name then break end
            if name == "PHYSICAL_TYPES" and type(value) == "table" then
              physicalTypes = value
              break
            end
          end
        end

        if physicalTypes then
          bridge = {
            active = false,
            physicalTypes = physicalTypes,
            originalPrepareMove = CrystalDamage.prepareMove,
            originalCompute = CrystalDamage.compute,
            categoryFor = nil,
          }
          rawset(CrystalDamage, BRIDGE_KEY, bridge)

          CrystalDamage.prepareMove = function(move, moves)
            local token = bridge.originalPrepareMove(move, moves)
            if token and bridge.active and bridge.categoryFor and move then
              local category = bridge.categoryFor(move, moves)
              if category then move.category = category end
            end
            return token
          end

          CrystalDamage.compute = function(ctx, config)
            if not (bridge.active and bridge.categoryFor and ctx and ctx.move) then
              return bridge.originalCompute(ctx, config)
            end
            local move = ctx.move
            local category = bridge.categoryFor(move, config and config.moves)
            if (category ~= "physical" and category ~= "special") or not move.type then
              return bridge.originalCompute(ctx, config)
            end

            local had = bridge.physicalTypes[move.type] ~= nil
            local previous = bridge.physicalTypes[move.type]
            bridge.physicalTypes[move.type] = category == "physical"

            local result = pack(pcall(bridge.originalCompute, ctx, config))

            if had then bridge.physicalTypes[move.type] = previous
            else bridge.physicalTypes[move.type] = nil end

            if not result[1] then error(result[2], 0) end
            return unpack(result, 2, result.n)
          end
        elseif mod.log and type(mod.log.warn) == "function" then
          mod.log:warn("Crystal 251 detected, but its physical-type dispatcher could not be located; registry categories were patched but Crystal damage routing could not be bridged")
        end
      end

      if bridge then
        bridge.active = moveSplitActive
        bridge.categoryFor = function(move, moves)
          local index = type(move) == "table" and tonumber(move.index) or nil
          if not index and type(CrystalDamage.moveFor) == "function" then
            local row = CrystalDamage.moveFor(move, moves)
            index = type(row) == "table" and tonumber(row.index) or nil
          end
          return index and GEN4_MOVE_CATEGORY_BY_INDEX[index] or nil
        end
        if moveSplitActive and mod.log and type(mod.log.info) == "function" then
          mod.log:info("Crystal 251 damage router compatibility enabled for GEN IV+ move categories")
        end
      end
    end
  end

  -- A single shared dispatcher state means a hot-reloaded copy can update the
  -- implementation without stacking wrappers on top of wrappers.
  local state = rawget(Stats, PATCH_KEY)
  if not state then
    state = {
      active = false,
      split = nil,
      originalCalc = Stats.calc,
      originalEnsure = Stats.ensure,
      originalDamage = Damage.compute,
      originalExperience = Experience.apply,
      originalItemUse = ItemEffects.use,
      originalSummaryDraw = SummaryMenu.draw,
      originalStatBoxDraw = BattleState.StatBox and BattleState.StatBox.draw,
      originalSave = SaveData.save,
      derivedStats = setmetatable({}, { __mode = "k" }),
      nativeLevelUpDrawSeen = setmetatable({}, { __mode = "k" }),
      splitStatBoxDraw = nil,
    }
    rawset(Stats, PATCH_KEY, state)

    -- Track exactly which stat tables received fields from THIS mod. The weak
    -- set lets SaveData.save remove only our derived fields before serialization
    -- without touching another mod that might use similarly named keys.
    state.attach = function(stats, speciesDef, level, dvs, statExp)
      state.split.attach(stats, speciesDef, level, dvs, statExp)
      if type(stats) == "table" then state.derivedStats[stats] = true end
      return stats
    end

    -- Keep vanilla fields intact for compatibility. Add two derived fields.
    Stats.calc = function(speciesDef, level, dvs, statExp)
      local out = state.originalCalc(speciesDef, level, dvs, statExp)
      if state.active and state.split then
        state.attach(out, speciesDef, level, dvs, statExp)
      end
      return out
    end

    Stats.ensure = function(speciesDef, mon)
      local out = state.originalEnsure(speciesDef, mon)
      if state.active and state.split and type(out) == "table" and type(out.stats) == "table" then
        state.attach(out.stats, speciesDef, out.level or 1, out.dvs or {}, out.statExp or {})
      end
      return out
    end

    -- Do NOT reimplement Gen1Recomp's damage formula. For a special move,
    -- temporarily alias the legacy "special" operand to attacker SpA and
    -- defender SpD, call the exact upstream Damage.compute, then restore.
    Damage.compute = function(ruleset, attacker, defender, move, opts)
      if not state.active or not state.split or not attacker or not defender then
        return state.originalDamage(ruleset, attacker, defender, move, opts)
      end

      local category = move and move.category
      if category == nil and move and move.type then
        category = require("src.battle.TypeChart").category(move.type)
      end
      if category ~= "special" then
        return state.originalDamage(ruleset, attacker, defender, move, opts)
      end

      -- Existing saves may contain mon.stats without the new derived fields.
      -- Only fill missing split fields here.  `curStats` can be a transformed
      -- battle-stat table whose SpA/SpD deliberately belong to the copied
      -- target species; recomputing them from battler.def would silently
      -- revert Transform to the user's original species for special damage.
      local function ensureCurrentSplit(b)
        if not (b and b.mon and b.def and b.curStats) then return end
        if b.curStats.specialAttack == nil or b.curStats.specialDefense == nil then
          state.attach(b.curStats, b.def, b.mon.level or 1,
                       b.mon.dvs or {}, b.mon.statExp or {})
        end
      end
      ensureCurrentSplit(attacker)
      ensureCurrentSplit(defender)

      local acs, dcs = attacker.curStats, defender.curStats
      local ast, dst = attacker.stages or {}, defender.stages or {}
      attacker.stages, defender.stages = ast, dst

      local save = {
        acsSpecial = acs.special,
        dcsSpecial = dcs.special,
        astSpecial = ast.special,
        dstSpecial = dst.special,
      }

      acs.special = acs.specialAttack or acs.special
      dcs.special = dcs.specialDefense or dcs.special
      ast.special = ast.specialAttack or 0
      dst.special = dst.specialDefense or 0

      local result = pack(pcall(state.originalDamage, ruleset, attacker, defender, move, opts))

      acs.special = save.acsSpecial
      dcs.special = save.dcsSpecial
      ast.special = save.astSpecial
      dst.special = save.dstSpecial

      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end

    -- Summary page 1: replace only the legacy four-stat block after the
    -- frozen upstream screen has rendered. This avoids duplicating the rest
    -- of SummaryMenu (sprites, palettes, types, OT/ID, page 2). The compact
    -- one-line layout fits five stats into the original 10x10 tile box.
    SummaryMenu.draw = function(self)
      state.originalSummaryDraw(self)
      if not state.active or not state.split or self.page ~= 1 or not self.mon then
        return
      end
      local mon = self.mon
      local def = self.game and self.game.data and self.game.data.pokemon
                  and self.game.data.pokemon[mon.species]
      if def then
        mon.stats = mon.stats or Stats.calc(def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
        state.attach(mon.stats, def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
      end
      local st = mon.stats or {}
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.rectangle("fill", 0, 64, 80, 80)
      Font.drawBox(0, 8, 10, 10)
      love.graphics.setColor(0, 0, 0, 1)
      local rows = {
        { "ATK", st.attack }, { "DEF", st.defense }, { "SPEED", st.speed },
        -- The summary box is only 10 tiles wide. Six fixed-width glyphs
        -- ("SP.ATK") would collide with the 3-digit value column, so the two
        -- split labels use compact five-glyph forms here only.
        { "SPATK", st.specialAttack or st.special },
        { "SPDEF", st.specialDefense or st.special },
      }
      for i, r in ipairs(rows) do
        -- Interior of Font.drawBox(0,8,10,10) is x=8..71, y=72..135.
        -- Five 8px labels occupy x=8..47; 3-digit values occupy x=48..71.
        local y = 72 + (i - 1) * 14
        Font.draw(Strings(r[1]), 8, y)
        Font.draw(("%3d"):format(r[2] or 0), 48, y)
      end
      love.graphics.setColor(1, 1, 1, 1)
    end

    -- Level-up StatBox: same principle as SummaryMenu. Keep the upstream
    -- state/update flow and replace only its draw routine with five rows.
    --
    -- `nativeLevelUpDrawSeen` is also a presentation signal owned entirely by
    -- this mod. If this draw actually runs in a frame, the native split card is
    -- visible and a Modern UI compatibility overlay must NOT be added. If a
    -- downstream UI decorator suppresses this draw, the signal stays false and
    -- the later render.hud compatibility layer can safely correct that foreign
    -- presentation without touching its implementation.
    if BattleState.StatBox and type(state.originalStatBoxDraw) == "function" then
      state.nativeLevelUpDrawSeen = state.nativeLevelUpDrawSeen
        or setmetatable({}, { __mode = "k" })
      state.splitStatBoxDraw = function(self)
        if not state.active or not state.split or not self.mon then
          return state.originalStatBoxDraw(self)
        end
        state.nativeLevelUpDrawSeen[self] = true
        local mon = self.mon
        local def = self.game and self.game.data and self.game.data.pokemon
                    and self.game.data.pokemon[mon.species]
        if def then
          mon.stats = mon.stats or Stats.calc(def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
          state.attach(mon.stats, def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
        end
        local st = mon.stats or {}
        Font.drawBox(9, 2, 11, 10)
        love.graphics.setColor(0, 0, 0, 1)
        local rows = {
          { "ATK", st.attack }, { "DEF", st.defense }, { "SPEED", st.speed },
          { "SP.ATK", st.specialAttack or st.special },
          { "SP.DEF", st.specialDefense or st.special },
        }
        for i, r in ipairs(rows) do
          -- Interior of Font.drawBox(9,2,11,10) is x=80..151, y=24..87.
          -- "SP.ATK"/"SP.DEF" occupy x=80..127; values x=128..151.
          local y = 24 + (i - 1) * 14
          Font.draw(Strings(r[1]), 80, y)
          Font.draw(("%3d"):format(r[2] or 0), 128, y)
        end
        love.graphics.setColor(1, 1, 1, 1)
      end
      BattleState.StatBox.draw = state.splitStatBoxDraw
    end

    -- Keep the on-disk save schema vanilla. Gen1Recomp serializes the full
    -- save table, including mon.stats, so derived SpA/SpD fields would otherwise
    -- leak into save.lua. Strip only stat tables tracked by this mod, call the
    -- exact upstream save routine, and restore in-memory fields even on error.
    SaveData.save = function(data, mods)
      if not state.active or not state.split then
        return state.originalSave(data, mods)
      end
      local removed, seen = {}, {}
      local function walk(value)
        if type(value) ~= "table" or seen[value] then return end
        seen[value] = true
        if state.derivedStats[value] then
          for _, key in ipairs({ "specialAttack", "specialDefense" }) do
            if value[key] ~= nil then
              removed[#removed + 1] = { tbl = value, key = key, value = value[key] }
              value[key] = nil
            end
          end
        end
        for _, child in pairs(value) do walk(child) end
      end
      walk(data)
      local result = pack(pcall(state.originalSave, data, mods))
      for i = #removed, 1, -1 do
        local r = removed[i]
        r.tbl[r.key] = r.value
      end
      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end

    -- Gen II keeps one shared Special Stat Exp. The defeated Pokémon's
    -- Special Attack base stat is the value added to that shared bucket.
    Experience.apply = function(data, mon, defeatedDef, level, isTrainer,
                                numParticipants, traded)
      if not state.active or not state.split or not defeatedDef then
        return state.originalExperience(data, mon, defeatedDef, level, isTrainer,
                                        numParticipants, traded)
      end
      local row = state.split.baseFor(defeatedDef)
      if not row or not defeatedDef.baseStats then
        return state.originalExperience(data, mon, defeatedDef, level, isTrainer,
                                        numParticipants, traded)
      end
      local old = defeatedDef.baseStats.special
      defeatedDef.baseStats.special = row.spa
      local result = pack(pcall(state.originalExperience, data, mon, defeatedDef,
                                level, isTrainer, numParticipants, traded))
      defeatedDef.baseStats.special = old
      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end

    -- X SPECIAL becomes a Sp. Atk stage boost. We preserve ItemEffects.use
    -- exactly and redirect only its temporary "special" stage slot.
    ItemEffects.use = function(data, saveData, itemId, target, battle, moveIndex, ow)
      if not state.active or itemId ~= "X_SPECIAL" or not battle or not battle.player then
        return state.originalItemUse(data, saveData, itemId, target, battle, moveIndex, ow)
      end
      local stages = battle.player.stages or {}
      battle.player.stages = stages
      local old = stages.special
      stages.special = stages.specialAttack or 0
      local result = pack(pcall(state.originalItemUse, data, saveData, itemId, target,
                                battle, moveIndex, ow))
      stages.specialAttack = stages.special or 0
      stages.special = old
      if result[1] then
        relabelMessages(result[3], Strings("SPECIAL"), Strings("SP. ATK"))
      end
      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end
  end

  state.active = active
  state.split = SplitStats
  state.nativeLevelUpDrawSeen = state.nativeLevelUpDrawSeen
    or setmetatable({}, { __mode = "k" })
  if not state.splitStatBoxDraw and BattleState.StatBox then
    -- Hot-reload bridge from pre-test4 builds: the existing shared dispatcher
    -- already owns BattleState.StatBox.draw, so remember that exact function as
    -- the native split draw identity instead of stacking another wrapper.
    state.splitStatBoxDraw = BattleState.StatBox.draw
  end

  -- Move-effect wrappers use the official move_effects registry. Calling the
  -- original record keeps Gen1Recomp's messages, Substitute/Mist behavior,
  -- chance rolls, and other edge cases; only the legacy stage slot is aliased.
  local function aliasStageRun(effectId, side, newKey)
    local originalRecord = MoveEffects.RECORDS[effectId]
    local originalRun = originalRecord and originalRecord.run
    if type(originalRun) ~= "function" then return end
    mod.content.move_effects:patch(effectId, {
      run = function(ctx)
        if not state.active then return originalRun(ctx) end
        local who = side == "user" and ctx.user or ctx.target
        if not who then return originalRun(ctx) end
        local stages = who.stages or {}
        who.stages = stages
        local old = stages.special
        stages.special = stages[newKey] or 0
        local result = pack(pcall(originalRun, ctx))
        stages[newKey] = stages.special or 0
        stages.special = old
        if result[1] then
          local label = newKey == "specialAttack" and "SP. ATK" or "SP. DEF"
          relabelMessages(result[2], Strings("SPECIAL"), Strings(label))
        end
        if not result[1] then error(result[2], 0) end
        return unpack(result, 2, result.n)
      end,
    })
  end

  -- Gen II meanings:
  -- Growth / SPECIAL_UP1 -> Sp. Atk +1
  -- Amnesia / SPECIAL_UP2 -> Sp. Def +2
  -- Psychic secondary Special drop -> Sp. Def -1
  aliasStageRun("SPECIAL_UP1_EFFECT", "user", "specialAttack")
  aliasStageRun("SPECIAL_UP2_EFFECT", "user", "specialDefense")
  aliasStageRun("SPECIAL_DOWN_SIDE_EFFECT", "target", "specialDefense")

  -- Transform copies both split stats and the target's stage table. The
  -- original effect already copies stages; we only add the two derived stats.
  do
    local originalRecord = MoveEffects.RECORDS.TRANSFORM_EFFECT
    local originalRun = originalRecord and originalRecord.run
    if type(originalRun) == "function" then
      mod.content.move_effects:patch("TRANSFORM_EFFECT", {
        run = function(ctx)
          local result = pack(pcall(originalRun, ctx))
          if result[1] and state.active and ctx.user and ctx.target then
            if ctx.target.curStats and ctx.user.curStats then
              ctx.user.curStats.specialAttack =
                ctx.target.curStats.specialAttack or ctx.target.curStats.special
              ctx.user.curStats.specialDefense =
                ctx.target.curStats.specialDefense or ctx.target.curStats.special
            end
          end
          if not result[1] then error(result[2], 0) end
          return unpack(result, 2, result.n)
        end,
      })
    end
  end

  -- Optional Pokédex Plus 1.3.x compatibility.  Pokédex Plus exposes
  -- its Base Stats page through the normal screens registry, so this can be
  -- composed without touching its private Lua locals.  The optional dependency
  -- guarantees Pokédex Plus registers the screen before this mod patches it.
  -- In VANILLA mode the original factory and draw path are returned untouched.
  do
    local pokedexPlus = type(mod.find) == "function" and mod.find("pokedex_plus") or nil
    local screens = mod.content and mod.content.screens
    if pokedexPlus and screens and type(screens.get) == "function"
        and type(screens.patch) == "function" then
      local originalRecord = screens:get("PokedexPlusStats")
      local originalNew = type(originalRecord) == "table" and originalRecord.new or nil
      if type(originalNew) == "function" then
        screens:patch("PokedexPlusStats", {
          new = function(game, opts)
            local screen = originalNew(game, opts)
            if not state.active or not state.split or type(screen) ~= "table" then
              return screen
            end

            local species = screen.species or (type(opts) == "table" and (opts.species or opts[1]))
            local def = game and game.data and game.data.pokemon and game.data.pokemon[species]
            local row = def and state.split.baseFor(def) or nil
            local stats = screen.stats
            local originalDraw = screen.draw
            if not row or type(stats) ~= "table" or type(originalDraw) ~= "function" then
              return screen
            end

            stats.specialAttack = row.spa
            stats.specialDefense = row.spd
            stats.total = (tonumber(stats.hp) or 0)
              + (tonumber(stats.attack) or 0)
              + (tonumber(stats.defense) or 0)
              + (tonumber(stats.speed) or 0)
              + row.spa + row.spd

            -- Let Pokédex Plus render its own header/type/footer exactly as-is,
            -- then replace only the legacy stat rows with a compact 7-row block.
            screen.draw = function(self)
              originalDraw(self)
              love.graphics.setColor(1, 1, 1, 1)
              love.graphics.rectangle("fill", 8, 40, 144, 88)
              love.graphics.setColor(0, 0, 0, 1)
              local labels = {
                { "HP", self.stats.hp },
                { "ATTACK", self.stats.attack },
                { "DEFENSE", self.stats.defense },
                { "SPEED", self.stats.speed },
                { "SP.ATK", self.stats.specialAttack },
                { "SP.DEF", self.stats.specialDefense },
                { "TOTAL", self.stats.total },
              }
              for i, statRow in ipairs(labels) do
                local y = 44 + (i - 1) * 12
                Font.draw(statRow[1], 16, y)
                local value = ("%03d"):format(statRow[2] or 0)
                Font.draw(value, 144 - Font.width(value), y)
              end
              love.graphics.setColor(1, 1, 1, 1)
            end
            return screen
          end,
        })
        mod.log:info("Pokédex Plus Base Stats compatibility enabled")
      else
        mod.log:warn("Pokédex Plus detected, but PokedexPlusStats screen was not available")
      end
    end
  end

  -- Optional Gen1 Modern UI compatibility.
  --
  -- IMPORTANT: ordinary Party/Summary compatibility intentionally does NOT use
  -- Modern UI's generic external-screen adapter. That adapter is useful for a
  -- source-owned custom screen, but replacing Modern UI's built-in Party or
  -- Summary presenter would throw away its authored sprites, HP bar, layout,
  -- spacing, frame and responsive detail card. `ModernUI Override` therefore
  -- uses a deliberately narrow, version-gated presentation shim: Modern UI
  -- renders its normal screen first, and this mod replaces only the legacy
  -- SPECIAL stat text inside Modern UI's own renderer.
  --
  -- This is temporary compatibility for the currently released Modern UI
  -- renderer. If upstream exposes an official built-in-detail augmentation
  -- contract, prefer that and remove this shim instead of expanding it.
  local function presentationStats(game, mon)
    if type(mon) ~= "table" then return {}, nil, nil end
    local stats = type(mon.stats) == "table" and mon.stats or {}
    local spa, spd = stats.specialAttack, stats.specialDefense
    if (spa == nil or spd == nil) and state.active and state.split then
      local def = game and game.data and game.data.pokemon
        and game.data.pokemon[mon.species]
      if def then
        spa, spd = state.split.calculate(def, mon.level or 1,
          mon.dvs or {}, mon.statExp or {}, stats.special)
      end
    end
    return stats, spa or stats.special, spd or stats.special
  end

  local function modernUiOverrideEnabled()
    return mod.options:get("modern_ui_override") ~= false
  end

  local function modernUiBattleWipOverrideEnabled()
    return mod.options:get("modern_ui_battle_wip_override") == true
  end

  local modernUiHandle = type(mod.find) == "function" and mod.find("gen1_modern_ui") or nil
  local modernUiExports = modernUiHandle and modernUiHandle.exports or nil
  local modernUiApiVersion = modernUiExports
    and (modernUiExports.compatibilityApiVersion or modernUiExports.version) or nil

  -- Current exact-layout shim target. Do not silently carry a private renderer
  -- patch across an upstream release number: a new Modern UI release may have
  -- changed geometry or may expose the cleaner augmentation seam we actually
  -- want. Unsupported releases are left completely untouched.
  local MODERN_UI_SURGICAL_RELEASES = { ["0.8.3"] = true }
  local MODERN_UI_SURGICAL_KEY = "__specialStatSplitModernUiSurgicalV1"

  local function closureUpvalue(fn, wanted)
    if type(fn) ~= "function" or type(debug) ~= "table"
        or type(debug.getupvalue) ~= "function" then
      return nil
    end
    for index = 1, 64 do
      local name, value = debug.getupvalue(fn, index)
      if name == nil then break end
      if name == wanted then return value end
    end
    return nil
  end


  local function installModernUiSurgicalOverride()
    if not modernUiHandle or tonumber(modernUiApiVersion) ~= 1 then return false end
    if not MODERN_UI_SURGICAL_RELEASES[tostring(modernUiHandle.version or "")] then
      if mod.log and type(mod.log.warn) == "function" then
        mod.log:warn("ModernUI Override does not patch unknown Gen1 Modern UI release %s; leaving its built-in UI untouched",
          tostring(modernUiHandle.version or "unknown"))
      end
      return false
    end

    local getter = modernUiExports and modernUiExports.getScaleTokens
    local runtime = closureUpvalue(getter, "runtime")
    if type(runtime) ~= "table" or type(runtime.drawParty) ~= "function"
        or type(runtime.drawMonDetail) ~= "function"
        or type(runtime.drawSummary) ~= "function" then
      if mod.log and type(mod.log.warn) == "function" then
        mod.log:warn("ModernUI Override could not resolve the expected 0.8.3 renderer; leaving Modern UI untouched")
      end
      return false
    end

    local previous = rawget(runtime, MODERN_UI_SURGICAL_KEY)
    if type(previous) == "table" and previous.owner == (mod.id or MOD_ID) then
      -- Hot reload: restore the exact upstream functions before installing the
      -- fresh wrapper so wrappers never stack around themselves.
      if runtime.drawParty == previous.wrappedParty and type(previous.originalParty) == "function" then
        runtime.drawParty = previous.originalParty
      end
      if runtime.drawMonDetail == previous.wrappedMonDetail and type(previous.originalMonDetail) == "function" then
        runtime.drawMonDetail = previous.originalMonDetail
      end
      if runtime.drawSummary == previous.wrappedSummary and type(previous.originalSummary) == "function" then
        runtime.drawSummary = previous.originalSummary
      end
    end

    local originalParty = runtime.drawParty
    local originalMonDetail = runtime.drawMonDetail
    local originalSummary = runtime.drawSummary

    -- Reuse Modern UI's own private drawing helpers/fonts from the exact
    -- renderer closure. This is why the shim is release-gated: we do not copy
    -- a second visual system, and we do not guess if upstream changes it.
    local detailFont = closureUpvalue(originalMonDetail, "font")
    local detailFontCache = closureUpvalue(originalMonDetail, "fontCache")
    local detailDrawFitted = closureUpvalue(originalMonDetail, "drawFittedText")
    local detailTextHeight = closureUpvalue(originalMonDetail, "textHeight")
    local detailSetColor = closureUpvalue(originalMonDetail, "setColor")

    local summaryPresenterRect = closureUpvalue(originalSummary, "presenterRect")
    local summaryPanelWidthFor = closureUpvalue(originalSummary, "panelWidthFor")
    local summaryFont = closureUpvalue(originalSummary, "font")
    local summaryFontCache = closureUpvalue(originalSummary, "fontCache")
    local summaryDrawFitted = closureUpvalue(originalSummary, "drawFittedText")
    local summaryTextHeight = closureUpvalue(originalSummary, "textHeight")
    local summarySetColor = closureUpvalue(originalSummary, "setColor")
    local summarySpriteFor = closureUpvalue(originalSummary, "spriteFor")

    local helpersOk = type(detailFont) == "function"
      and type(detailFontCache) == "table"
      and type(detailDrawFitted) == "function"
      and type(detailTextHeight) == "function"
      and type(detailSetColor) == "function"
      and type(summaryPresenterRect) == "function"
      and type(summaryPanelWidthFor) == "function"
      and type(summaryFont) == "function"
      and type(summaryFontCache) == "table"
      and type(summaryDrawFitted) == "function"
      and type(summaryTextHeight) == "function"
      and type(summarySetColor) == "function"
      and type(summarySpriteFor) == "function"
    if not helpersOk then
      if mod.log and type(mod.log.warn) == "function" then
        mod.log:warn("ModernUI Override 0.8.3 renderer signature changed; leaving Modern UI untouched")
      end
      return false
    end

    local bridge = {
      owner = mod.id or MOD_ID,
      release = tostring(modernUiHandle.version or ""),
      originalParty = originalParty,
      originalMonDetail = originalMonDetail,
      originalSummary = originalSummary,
      inParty = false,
      partyIsBattle = false,
    }

    local function drawPartyStatRow(game, mon, x, y, w, h, theme, context)
      if context ~= "party" or not bridge.inParty
          or not (state.active and state.split and type(mon) == "table") then
        return
      end
      local enabled = bridge.partyIsBattle
        and modernUiBattleWipOverrideEnabled() or modernUiOverrideEnabled()
      if not enabled then return end
      local spacing, colors = theme and theme.spacing, theme and theme.colors
      if not (spacing and colors and love and love.graphics
          and type(love.graphics.rectangle) == "function") then return end

      local stats, spa, spd = presentationStats(game, mon)
      if spa == nil or spd == nil then return end
      local compact = h < 250 or w < 360
      local titleFont = detailFont(detailFontCache, compact and theme.typography.body
        or theme.typography.title)
      local bodyFont = detailFont(detailFontCache, compact and theme.typography.caption
        or theme.typography.body)
      local captionFont = detailFont(detailFontCache, theme.typography.caption)
      local artSize = math.max(54, math.min(compact and 92 or 150,
        h * (compact and 0.42 or 0.48), w * 0.30))
      local lowerY = y + math.max(artSize + spacing.md * 2,
        detailTextHeight(titleFont) + detailTextHeight(captionFont) * 2
          + spacing.xl * 2)
      local rowH = detailTextHeight(bodyFont)
      local left = x + spacing.md
      local innerW = math.max(1, w - spacing.md * 2)
      local gap = math.max(1, math.min(spacing.xs or 1, spacing.sm or 1))
      local statWidth = math.max(20, (innerW - gap * 4) / 5)
      local statText = {
        ("ATK %s"):format(tostring(stats.attack or "—")),
        ("DEF %s"):format(tostring(stats.defense or "—")),
        ("SPD %s"):format(tostring(stats.speed or "—")),
        ("SPATK %s"):format(tostring(spa or "—")),
        ("SPDEF %s"):format(tostring(spd or "—")),
      }
      -- Five cells need slightly more horizontal room than Modern UI's native
      -- four-cell row. Keep the exact Modern UI typeface and only reduce this
      -- one row's font token when a real value would otherwise truncate.
      local rowFont = bodyFont
      local widest = 0
      for _, value in ipairs(statText) do
        widest = math.max(widest, bodyFont:getWidth(value))
      end
      if widest > statWidth then
        local baseSize = compact and theme.typography.caption or theme.typography.body
        -- Scale only this one text row just enough for the longest real value.
        -- The 0.92 safety factor avoids Modern UI's fitted-text ellipsis at
        -- glyph-rounding boundaries while preserving every surrounding pixel.
        local fitScale = math.min(1, (statWidth / math.max(1, widest)) * 0.92)
        rowFont = detailFont(detailFontCache, math.max(8, baseSize * fitScale))
      end

      love.graphics.push("all")
      love.graphics.setFont(rowFont)
      -- Erase ONLY Modern UI's original four-stat text row. The selected
      -- Pokémon card, sprite, HP bar, move list, frame and every surrounding
      -- pixel remain the upstream renderer's output.
      detailSetColor(colors.surfaceRaised)
      love.graphics.rectangle("fill", left - 1, lowerY - 1,
        innerW + 2, rowH + 2)
      detailSetColor(colors.textMuted)
      for index, value in ipairs(statText) do
        detailDrawFitted(value,
          left + (index - 1) * (statWidth + gap), lowerY,
          statWidth, rowFont)
      end
      love.graphics.pop()
    end

    local function drawSummarySpecialRow(game, screen, viewport, theme)
      if not (modernUiOverrideEnabled() and state.active and state.split
          and type(screen) == "table" and type(theme) == "table") then return end
      local page = screen.page
      if not (page == nil or page == 1) then return end
      local mon = runtime.summaryPokemon(screen) or {}
      if type(mon) ~= "table" or mon.species == nil then return end
      local stats, spa, spd = presentationStats(game, mon)
      if spa == nil or spd == nil then return end

      local x, y, w, h = summaryPresenterRect(viewport)
      local spacing = theme.spacing
      local gutter = spacing.lg
      local panelW = summaryPanelWidthFor(viewport, w - gutter * 2,
        runtime.panelMaxWidth(theme, 780))
      local def = runtime.pokemonDefinition(game, mon.species)
      local summarySprite = summarySpriteFor(game, mon, nil, "summary")
      panelW = math.min(panelW, runtime.scaledPanelWidth(theme, 640))
      local compact = panelW < 620
      local titleFont = summaryFont(summaryFontCache,
        compact and theme.typography.title * 0.86 or theme.typography.title)
      local bodyFont = summaryFont(summaryFontCache,
        compact and theme.typography.body * 0.86 or theme.typography.body)
      local captionFont = summaryFont(summaryFontCache, theme.typography.caption)
      local titleH = summaryTextHeight(titleFont)
      local lineGap = compact and (summaryTextHeight(bodyFont) + spacing.xs)
        or (spacing.lg + 10)
      local bodyLine = summaryTextHeight(bodyFont) + spacing.xs
      local titleOffset = spacing.md + titleH + spacing.xs
      local pageOffset = titleOffset
      local levelOffset = pageOffset + summaryTextHeight(bodyFont) + spacing.xs
      local hpOffset = levelOffset + lineGap
      local statusOffset = hpOffset + lineGap
      local spriteSize = compact and math.min(112, panelW * 0.24) or 150
      local spriteBottom = summarySprite
        and (statusOffset + lineGap * 2 + spacing.sm + spriteSize)
        or (statusOffset + lineGap)
      local statGap = compact and bodyLine or 28
      local statsBottom = pageOffset + statGap * 5 + summaryTextHeight(bodyFont)
      local contentBottom = math.max(spriteBottom, statsBottom)
      local panelH = math.min(h - gutter * 2,
        contentBottom + spacing.lg + summaryTextHeight(captionFont) + spacing.md)
      local px, py = x + (w - panelW) / 2, y + (h - panelH) / 2
      local pageY = py + spacing.md + titleH + spacing.xs
      local infoX = compact and (px + panelW * 0.48) or (px + panelW * 0.52)
      local rowY = pageY + statGap * 3 -- exact upstream SPECIAL row
      local right = px + panelW - spacing.lg
      local available = math.max(24, right - infoX)
      local pairGap = spacing.md
      local pairW = math.max(12, (available - pairGap) / 2)
      local rowH = summaryTextHeight(bodyFont)

      love.graphics.push("all")
      love.graphics.setFont(bodyFont)
      -- Replace ONLY the existing SPECIAL line. ID and OT stay at their exact
      -- upstream coordinates, so panel sizing and all other Summary geometry
      -- remain byte-for-byte Modern UI decisions.
      summarySetColor(theme.colors.surface)
      love.graphics.rectangle("fill", infoX - 1, rowY - 1,
        available + 2, rowH + 2)

      local function drawPair(label, value, pairX)
        summarySetColor(theme.colors.textMuted)
        summaryDrawFitted(label, pairX, rowY, pairW, bodyFont)
        local valueX = pairX + bodyFont:getWidth(label) + spacing.xs
        summarySetColor(theme.colors.text)
        summaryDrawFitted(tostring(value or "—"), valueX, rowY,
          math.max(8, pairW - (valueX - pairX)), bodyFont)
      end
      drawPair("SP.ATK", spa, infoX)
      drawPair("SP.DEF", spd, infoX + pairW + pairGap)
      love.graphics.pop()
    end

    bridge.wrappedParty = function(game, screen, viewport, theme)
      local previousInParty, previousBattle = bridge.inParty, bridge.partyIsBattle
      bridge.inParty = true
      bridge.partyIsBattle = type(screen) == "table" and screen.battle ~= nil
      local results = pack(pcall(originalParty, game, screen, viewport, theme))
      bridge.inParty, bridge.partyIsBattle = previousInParty, previousBattle
      if not results[1] then error(results[2], 0) end
      return unpack(results, 2, results.n)
    end

    bridge.wrappedMonDetail = function(game, mon, x, y, w, h, theme, context)
      local results = pack(pcall(originalMonDetail, game, mon, x, y, w, h, theme, context))
      if not results[1] then error(results[2], 0) end
      drawPartyStatRow(game, mon, x, y, w, h, theme, context)
      return unpack(results, 2, results.n)
    end

    bridge.wrappedSummary = function(game, screen, viewport, theme)
      local results = pack(pcall(originalSummary, game, screen, viewport, theme))
      if not results[1] then error(results[2], 0) end
      drawSummarySpecialRow(game, screen, viewport, theme)
      return unpack(results, 2, results.n)
    end

    bridge.restore = function()
      if runtime.drawParty == bridge.wrappedParty then runtime.drawParty = originalParty end
      if runtime.drawMonDetail == bridge.wrappedMonDetail then runtime.drawMonDetail = originalMonDetail end
      if runtime.drawSummary == bridge.wrappedSummary then runtime.drawSummary = originalSummary end
    end

    runtime.drawParty = bridge.wrappedParty
    runtime.drawMonDetail = bridge.wrappedMonDetail
    runtime.drawSummary = bridge.wrappedSummary
    rawset(runtime, MODERN_UI_SURGICAL_KEY, bridge)

    if mod.log and type(mod.log.info) == "function" then
      mod.log:info("ModernUI Override enabled as a surgical Gen1 Modern UI %s stat-row shim",
        tostring(modernUiHandle.version))
    end
    return true
  end

  local modernUiSurgicalInstalled = installModernUiSurgicalOverride()
  mod.exports = mod.exports or {}
  mod.exports.modernUiSurgicalInstalled = function() return modernUiSurgicalInstalled end

  -- Optional ModernUI BattleWIP Override. This is deliberately OFF by default
  -- so Special Stat Split never replaces another mod's experimental battle
  -- presentation unless the player explicitly opts in.
  --
  -- Modern UI 0.8.x has a dedicated battle LEVEL UP card that is not a
  -- generic presenter/adaptable screen. On Gen1Recomp v0.1.75 it suppresses
  -- the native BattleState.StatBox earlier than screen.render_visible: its
  -- public ui.state.decorate hook replaces the child state's draw method and
  -- later paints a four-row ATTACK/DEFENSE/SPEED/SPECIAL card from render.hud.
  --
  -- Do not modify Modern UI or call its private runtime. Observe two public
  -- seams plus our own native draw:
  --   1) ui.state.decorate records when a downstream decorator replaces our
  --      exact source-owned split StatBox draw;
  --   2) our native split draw marks the frame only when it actually executes;
  --   3) render.hud calls downstream first, then corrects the foreign card only
  --      when the decorator is still installed AND the native draw never ran.
  --
  -- This matters because Modern UI's BATTLE UI (WIP) is experimental and OFF
  -- by default. The player must ALSO opt into this mod's
  -- `ModernUI BattleWIP Override`; with either option off, or whenever the
  -- native StatBox remains visible, this path stays completely inert.
  --
  -- Compatibility is keyed to Modern UI's public compatibility API version,
  -- not its release number. A future Modern UI release that keeps API v1 and
  -- the same public decoration behavior can continue to work. If the public
  -- API version changes, this override fails closed instead of guessing.
  do
    local hooks = mod.hooks
    if modernUiHandle and tonumber(modernUiApiVersion) == 1
        and hooks and type(hooks.wrap) == "function"
        and BattleState.StatBox then
      local decoratedLevelUpBoxes = setmetatable({}, { __mode = "k" })
      local levelUpFonts = {}

      local function isStatBox(screen)
        if type(screen) ~= "table" then return false end
        local mt = getmetatable(screen)
        return mt == BattleState.StatBox
          or rawget(screen, "_specialStatSplitLevelUpProbe") == true
      end

      local function viewportRect(viewport)
        if viewport and type(viewport.safe) == "table" then
          local safe = viewport.safe
          return tonumber(safe.x) or 0, tonumber(safe.y) or 0,
            math.max(1, tonumber(safe.width) or tonumber(viewport.width) or 1),
            math.max(1, tonumber(safe.height) or tonumber(viewport.height) or 1)
        end
        if viewport and viewport.safeX ~= nil then
          return tonumber(viewport.safeX) or 0, tonumber(viewport.safeY) or 0,
            math.max(1, tonumber(viewport.safeWidth) or tonumber(viewport.width) or 1),
            math.max(1, tonumber(viewport.safeHeight) or tonumber(viewport.height) or 1)
        end
        local lg = love and love.graphics
        local w = viewport and tonumber(viewport.width)
          or (lg and type(lg.getWidth) == "function" and lg.getWidth()) or 640
        local h = viewport and tonumber(viewport.height)
          or (lg and type(lg.getHeight) == "function" and lg.getHeight()) or 360
        return 0, 0, math.max(1, w), math.max(1, h)
      end

      local function modernScaleTokens(viewport)
        local exports = modernUiHandle and modernUiHandle.exports
        local getter = exports and exports.getScaleTokens
        if type(getter) == "function" then
          local ok, tokens = pcall(getter, viewport)
          if ok and type(tokens) == "table" then return tokens end
        end
        return { uiScale = 1, fontScale = 1 }
      end

      local function levelUpFont(size)
        local lg = love and love.graphics
        if not (lg and type(lg.newFont) == "function") then return nil end
        local rounded = math.max(10, math.floor((tonumber(size) or 15) + 0.5))
        local raster = math.max(15, math.floor(rounded / 15 + 0.5) * 15)
        if levelUpFonts[raster] ~= nil then return levelUpFonts[raster] or nil end
        local path = Font.PLAINPIXEL or "assets/fonts/plainpixel/PlainPixel-Regular.ttf"
        local ok, font = pcall(lg.newFont, path, raster, "mono", 1)
        if not ok then ok, font = pcall(lg.newFont, path, raster, "mono") end
        if not ok then ok, font = pcall(lg.newFont, raster) end
        if ok and font then
          if type(font.setFilter) == "function" then
            pcall(font.setFilter, font, "nearest", "nearest", 0)
          end
          levelUpFonts[raster] = font
          return font
        end
        levelUpFonts[raster] = false
        return nil
      end

      local function fontHeight(font, fallback)
        if font and type(font.getHeight) == "function" then
          local ok, value = pcall(font.getHeight, font)
          if ok and tonumber(value) then return tonumber(value) end
        end
        return fallback
      end

      local function drawCorrectLevelUp(game, viewport, statBox)
        local lg = love and love.graphics
        if not (lg and type(lg.rectangle) == "function") then return false end
        local mon = statBox and (statBox.mon or statBox.pokemon)
        if type(mon) ~= "table" then return false end
        local def = game and game.data and game.data.pokemon
          and game.data.pokemon[mon.species]
        if def then
          mon.stats = mon.stats or Stats.calc(def, mon.level or 1,
            mon.dvs or {}, mon.statExp or {})
          state.attach(mon.stats, def, mon.level or 1,
            mon.dvs or {}, mon.statExp or {})
        end
        local stats = mon.stats
        if type(stats) ~= "table"
            or stats.specialAttack == nil or stats.specialDefense == nil then
          return false
        end

        local x, y, w, h = viewportRect(viewport)
        local touch = game and game.touchControls
        if touch and type(touch.visible) == "function" and type(touch.layout) == "function" then
          local stack = game and game.stack
          local hidden = stack and type(stack.touchControlsHidden) == "function"
            and stack:touchControlsHidden() or false
          local okVisible, visible = pcall(touch.visible, touch)
          if not hidden and okVisible and visible then
            local okLayout, controls = pcall(touch.layout, touch)
            if okLayout and type(controls) == "table" and h > w * 1.2 then
              local lowerTop = y + h
              for _, name in ipairs({ "dpad", "a", "b", "start", "select" }) do
                local zone = controls[name]
                if type(zone) == "table" and type(zone.cy) == "number"
                    and type(zone.w) == "number" and zone.cy > y + h * 0.52 then
                  local radius = zone.w * 0.58
                  if name == "start" or name == "select" then radius = radius + zone.w * 0.28 end
                  lowerTop = math.min(lowerTop, zone.cy - radius)
                end
              end
              local occupied = math.max(0, y + h - lowerTop + 10)
              if occupied > 12 then
                occupied = math.min(occupied, math.max(180, h * 0.30))
                h = math.max(1, h - occupied)
              end
            end
          end
        end

        local gx, gy = viewport and tonumber(viewport.gameX), viewport and tonumber(viewport.gameY)
        local gw, gh = viewport and tonumber(viewport.gameWidth), viewport and tonumber(viewport.gameHeight)
        if gx and gy and gw and gh and gw > 0 and gh > 0 then
          local right, bottom = math.min(x + w, gx + gw), math.min(y + h, gy + gh)
          local nx, ny = math.max(x, gx), math.max(y, gy)
          if right > nx and bottom > ny then x, y, w, h = nx, ny, right - nx, bottom - ny end
        end

        local tokens = modernScaleTokens(viewport)
        local uiScale = math.max(0.75, math.min(1.5, tonumber(tokens.uiScale) or 1))
        local fontScale = math.max(0.8, math.min(2.0, tonumber(tokens.fontScale) or 1))
        local md = math.max(10, math.floor(13 * uiScale + 0.5))
        local sm = math.max(7, math.floor(9 * uiScale + 0.5))
        local xs = math.max(4, math.floor(5 * uiScale + 0.5))
        local inset = math.max(md, math.floor(math.min(w, h) * 0.018))
        local titleFont = levelUpFont(24 * fontScale)
        local bodyFont = levelUpFont(17 * fontScale)
        local captionFont = levelUpFont(13 * fontScale)
        local titleH = fontHeight(titleFont, math.max(20, 24 * fontScale))
        local bodyH = fontHeight(bodyFont, math.max(14, 17 * fontScale))
        local captionH = fontHeight(captionFont, math.max(12, 13 * fontScale))
        local tileH = math.max(bodyH, captionH) + sm * 2

        local panelW = math.min(math.max(1, w - inset * 2),
          math.max(340, math.min(520, w * 0.55)))
        local panelH = md + titleH + xs + bodyH + md
          + tileH * 3 + sm * 2 + md
        panelH = math.min(math.max(1, h - inset * 2), panelH)
        local panelX
        if w < 640 then panelX = x + (w - panelW) / 2
        else panelX = x + w - panelW - inset end
        local panelY = y + math.max(inset, (h - panelH) * 0.30)

        local pushed = type(lg.push) == "function"
        if pushed then lg.push("all") end
        if type(lg.origin) == "function" then lg.origin() end

        if type(lg.setColor) == "function" then lg.setColor(0.035, 0.045, 0.055, 1) end
        lg.rectangle("fill", panelX, panelY, panelW, panelH, math.max(4, 8 * uiScale))
        if type(lg.setLineWidth) == "function" then lg.setLineWidth(math.max(2, 2 * uiScale)) end
        if type(lg.setColor) == "function" then lg.setColor(0.88, 0.92, 0.96, 1) end
        lg.rectangle("line", panelX, panelY, panelW, panelH, math.max(4, 8 * uiScale))
        if type(lg.setColor) == "function" then lg.setColor(0.30, 0.72, 0.94, 1) end
        lg.rectangle("fill", panelX, panelY, panelW, math.max(3, 4 * uiScale))

        local function setFont(f)
          if f and type(lg.setFont) == "function" then lg.setFont(f) end
        end
        local function printText(text, px, py)
          if type(lg.print) == "function" then lg.print(tostring(text or ""), px, py) end
        end
        local function textWidth(f, text)
          if f and type(f.getWidth) == "function" then
            local ok, value = pcall(f.getWidth, f, tostring(text or ""))
            if ok and tonumber(value) then return tonumber(value) end
          end
          return #tostring(text or "") * math.max(8, 8 * fontScale)
        end

        setFont(titleFont)
        if type(lg.setColor) == "function" then lg.setColor(1, 1, 1, 1) end
        printText("LEVEL UP!", panelX + md, panelY + md)
        local identityY = panelY + md + titleH + xs
        setFont(bodyFont)
        local nickname = tostring(mon.nickname or mon.name or mon.species or "POKEMON")
        local levelText = "Lv " .. tostring(mon.level or "")
        printText(nickname, panelX + md, identityY)
        if type(lg.setColor) == "function" then lg.setColor(0.72, 0.78, 0.84, 1) end
        printText(levelText, panelX + panelW - md - textWidth(bodyFont, levelText), identityY)

        local rows = {
          { { "ATTACK", stats.attack }, { "DEFENSE", stats.defense } },
          { { "SPEED", stats.speed }, { "SP. ATK", stats.specialAttack } },
          { { "SP. DEF", stats.specialDefense }, nil },
        }
        local gridY = identityY + bodyH + md
        local columnW = (panelW - md * 2 - sm) / 2
        for line, pair in ipairs(rows) do
          for column = 1, 2 do
            local row = pair[column]
            if row then
              local cellX = panelX + md + (column - 1) * (columnW + sm)
              local cellY = gridY + (line - 1) * (tileH + sm)
              if type(lg.setColor) == "function" then lg.setColor(0.10, 0.13, 0.16, 1) end
              lg.rectangle("fill", cellX, cellY, columnW, tileH, math.max(3, 5 * uiScale))
              if type(lg.setColor) == "function" then lg.setColor(0.28, 0.34, 0.40, 1) end
              lg.rectangle("line", cellX, cellY, columnW, tileH, math.max(3, 5 * uiScale))
              setFont(captionFont)
              if type(lg.setColor) == "function" then lg.setColor(0.72, 0.78, 0.84, 1) end
              printText(row[1], cellX + sm, cellY + (tileH - captionH) / 2)
              local valueText = tostring(row[2] or 0)
              setFont(bodyFont)
              if type(lg.setColor) == "function" then lg.setColor(1, 1, 1, 1) end
              printText(valueText, cellX + columnW - sm - textWidth(bodyFont, valueText),
                cellY + (tileH - bodyH) / 2)
            end
          end
        end

        if pushed and type(lg.pop) == "function" then lg.pop() end
        return true
      end

      hooks:wrap("ui.state.decorate", function(next, game, screen, model)
        local beforeDraw = isStatBox(screen) and screen.draw or nil
        local result = pack(next(game, screen, model))
        local decorated = type(result[1]) == "table" and result[1] or screen
        if not modernUiBattleWipOverrideEnabled() then
          if isStatBox(decorated) then decoratedLevelUpBoxes[decorated] = nil end
          return unpack(result, 1, result.n)
        end
        if isStatBox(decorated) then
          local afterDraw = decorated.draw
          -- The source-owned split draw is the only identity we treat as the
          -- native baseline. A downstream decorator changing THAT exact method
          -- records a candidate Modern Battle UI level-up wrapper. Conversely,
          -- if a later decoration pass restores our draw (Battle UI toggled
          -- back off), retire the candidate immediately.
          if type(state.splitStatBoxDraw) == "function"
              and beforeDraw == state.splitStatBoxDraw
              and type(afterDraw) == "function"
              and afterDraw ~= state.splitStatBoxDraw then
            decoratedLevelUpBoxes[decorated] = { draw = afterDraw }
          elseif afterDraw == state.splitStatBoxDraw then
            decoratedLevelUpBoxes[decorated] = nil
          end
        end
        return unpack(result, 1, result.n)
      end, 200)

      hooks:wrap("render.hud", function(next, game, viewport)
        -- Modern UI's priority-100 HUD paints its experimental battle layer
        -- downstream. Calling next first guarantees our correction lands on top
        -- of its obsolete four-stat card rather than underneath it.
        local result = pack(next(game, viewport))
        local stack = game and game.stack
        local top
        if stack and type(stack.top) == "function" then
          local ok, value = pcall(stack.top, stack)
          if ok then top = value end
        end
        if not top and stack and type(stack.states) == "table" then
          top = stack.states[#stack.states]
        end

        local nativeWasDrawn = top and state.nativeLevelUpDrawSeen[top] == true
        if top then state.nativeLevelUpDrawSeen[top] = nil end
        local decorated = top and decoratedLevelUpBoxes[top] or nil

        if modernUiBattleWipOverrideEnabled()
            and state.active and state.split and isStatBox(top)
            and type(decorated) == "table"
            and top.draw == decorated.draw
            and not nativeWasDrawn then
          -- This is the key fail-safe missing from test3: a mere Modern UI
          -- install is not enough. The correction appears only when the foreign
          -- decorator is still installed AND our own native five-stat draw did
          -- not execute in this frame. With the WIP Battle UI off (its default),
          -- or HIDE ORIGINAL UI allowing the native child to draw, this stays
          -- completely inert.
          drawCorrectLevelUp(game, viewport, top)
        end
        return unpack(result, 1, result.n)
      end, 200)
    end
  end

  mod.exports = mod.exports or {}
  mod.exports.specialSplitActive = function() return state.active end
  mod.exports.moveCategorySplitActive = function() return moveSplitActive end
  mod.exports.modernUiOverrideEnabled = modernUiOverrideEnabled
  mod.exports.modernUiBattleWipOverrideEnabled = modernUiBattleWipOverrideEnabled
  -- Backward-compatible alias for prerelease consumers of the old test API.
  mod.exports.modernUiLevelUpOverrideEnabled = modernUiBattleWipOverrideEnabled
  mod.exports.getMoveCategory = function(move)
    if not moveSplitActive then return nil end
    local index = type(move) == "table" and move.index or move
    return GEN4_MOVE_CATEGORY_BY_INDEX[tonumber(index)]
  end
  -- Small inter-mod API for UI mods (for example a Pokédex base-stat page).
  -- Returns nil in VANILLA mode so consumers can fall back to legacy SPECIAL.
  mod.exports.getSpecialBaseStats = function(species)
    if not state.active or not state.split then return nil end
    local def = type(species) == "table" and species or { id = species }
    local row = state.split.baseFor(def)
    if not row then return nil end
    return { specialAttack = row.spa, specialDefense = row.spd }
  end
  mod.exports.attachSplitStats = function(mon, speciesDef)
    if not state.active or not mon or not speciesDef then return mon end
    mon.stats = mon.stats or Stats.calc(speciesDef, mon.level or 1, mon.dvs or {}, mon.statExp or {})
    state.attach(mon.stats, speciesDef, mon.level or 1, mon.dvs or {}, mon.statExp or {})
    return mon
  end
end
