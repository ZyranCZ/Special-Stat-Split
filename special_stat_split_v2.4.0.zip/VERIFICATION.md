# Verification report — v2.4.0

Frozen target: Gen1Recomp `v0.1.75`, commit `60cf07fb0a1ffce0ec6d5d0d2f78a921a6d0b7da`.

## Source baseline discipline — PASS

- Final release source was the exact assistant-delivered `special_stat_split_v2.4.0-test3.zip`, SHA-256 `324516bd2e8bc8e8d9031366997ef4e1d33385504fa231ac640d0df5d89074f6`.
- The final promotion changes no executable gameplay/UI logic in `main.lua`; its only `main.lua` change is the version comment.
- Immediate baseline for the final promotion: `v2.4.0-test3`, SHA-256 `324516bd2e8bc8e8d9031366997ef4e1d33385504fa231ac640d0df5d89074f6`.
- The preceding test3 development step itself was based on assistant-delivered `v2.4.0-test2`, SHA-256 `df1aa365b3a169aca72e86388c0af76a852e8c90e43dc481dc22aa436235bdfb`.
- The user-supplied older package was not used as the modification source.


## Integrated Move Category Readout — PASS

- Option `MOVE CATEGORY READOUT` exists and defaults ON.
- ON/OFF is presentation-only and read live; no restart is required.
- GEN IV+ mode follows explicit merged `move.category`; GEN I mode follows TypeChart fallback.
- Damaging Fire Punch regression: GEN IV+ -> `PHYS/`; GEN I -> `SPEC/`.
- Status/power-0 records retain `TYPE/`.
- Outside `moveSelect` / after `battle.ended`, vanilla `TYPE/` is retained.
- Standalone `move_category` coexistence is tested with both wrappers active; the final label is emitted once and no manifest conflict is declared.
- A module-level dispatcher sentinel prevents Special Stat Split hot reload from stacking another copy of its own Font wrapper.

## Launcher update metadata — PASS

- Manifest keeps `github = ZyranCZ/Special-Stat-Split`.
- Mod id remains `special_stat_split` and release version is `2.4.0`.
- `move_category` is optional only; the combined mod's update source remains the Special Stat Split repository.

## Crystal 251 interoperability contract

The packaged test suite now includes `tests/crystal251_contract.lua`. It verifies:

- canonical unequal Johto split bases (Togetic 80/105; Espeon 130/95; Umbreon 60/130);
- deliberately wrong/equal Crystal exports (Togetic 99/99 and Espeon 99/99) are ignored in favor of the mod-owned canonical table;
- registry and private-runtime category synchronization for Gen II moves;
- Fire/Normal/Flying/Poison/Electric/Dark/Ghost category inversions that would fail under Crystal's native type-based dispatcher;
- the Crystal damage bridge keeps the elemental type intact;
- the temporary dispatcher override is restored after both normal calls and forced errors;
- standalone GEN II/GEN IV, GEN II/GEN I, VANILLA/GEN IV and VANILLA/GEN I contracts still pass independently.

`verify_gen4_move_categories.py` now validates **251/251** category rows with totals 106 Physical / 52 Special / 93 Status. The separate generation-history audit remains intentionally scoped to the 165 original Gen I moves.

## Reference/stat data — PASS

- **251/251** National Dex #001–251 species exactly once.
- **502/502** Gen II–V Sp. Atk/Sp. Def values cross-checked.
- Shared Special DV/Stat Exp behavior and split-stat formula contracts pass.

## Move category data — PASS

- 251/251 Gen I+II modern category entries exactly once.
- Counts: 106 Physical / 52 Special / 93 Status.
- Slots 166..251 are applied only when Crystal 251 supplies the matching canonical records.
- 165/165 exact Gen1Recomp registry identity entries.
- Exact legacy-ID sentinels include `PSYCHIC_M`, `HI_JUMP_KICK`, `THUNDERPUNCH` and `SONICBOOM`.
- 18 Gen I -> GEN IV+ damaging category flips confirmed.

## Generation history audit — PASS

- 165/165 original moves compared across Gen IV, V, VI, VII, VIII and IX.
- Zero category differences among those six later generations for this move pool.
- Four Gen I -> Gen II elemental-type migrations documented separately.
- Packaged non-category changelog contains 83 field changes affecting 51 original moves from Gen IV onward.

## Collision contracts — PASS

The runtime registry stub deliberately injects an earlier wrong Fire Punch category and a fake custom move that reuses index 7. Tests prove:

- GEN IV+ overwrites the earlier canonical category with the audited value.
- GEN I mode removes an earlier canonical explicit category via `mod.DELETE` and restores by-type fallback.
- The fake reused-index custom move is skipped.
- Exact `HI_JUMP_KICK` registry identity is recognized despite modern naming differences.

## Damage/math contracts — PASS

- All stat stages -6..+6 and clamp behavior.
- Exact floor-sensitive SpA/SpD vectors.
- Light Screen, Volcano Badge operand ordering, faithful crit bypass, modern-clean crit stage path and physical control vector.
- Fire Punch demonstrates Attack/Defense routing in modern mode.
- Hyper Beam demonstrates Sp. Atk/Sp. Def routing when split stats are enabled.
- All four combinations of Special-stat mode x category mode execute successfully.

## Engine category-use audit — PASS

The frozen Lua target was searched globally. Explicit `move.category` is consumed by `src/battle/Damage.lua`; no additional trainer-AI or hidden move-effect category consumer was found. The ordinary damage function gives the explicit field precedence over type fallback.

## Frozen upstream integration

The complete frozen integration suite was rerun for v2.4.0 against the exact Gen1Recomp v0.1.75 source snapshot and passed its source-hash, battle/stat, save, and lifecycle contracts.

## Manual release gates still open

- Broad live compatibility smoke with the user's actual active move/type/UI mod set after the new collision guard.
- Dedicated two-peer link smoke if the release is to be explicitly advertised as link-certified.

The earlier behavior is not being silently reclassified as a full modern battle engine. v2.4.0 is based on the exact assistant-delivered v2.4.0-test2 and changes Modern UI presentation ownership only; split-stat/category/Crystal gameplay and the integrated Move Category readout remain intact.


## Manual release state

- Existing split-stat / Modern UI gameplay smoke: **PASS (user-reported on prior test builds)**.
- New integrated Move Category readout: **automated + exact standalone coexistence PASS; live smoke still recommended**.
- Dedicated two-peer live link battle: **not separately verified**.

## PASS — Modern UI Party/Summary surgical override contract (current code)

- The previous generic Party/Summary adapter is not registered. Modern UI remains the owner of the complete built-in presenters.
- The ordinary override is deliberately release-gated to Gen1 Modern UI 0.8.3 + compatibility API v1. Unknown release numbers fail closed.
- The real Modern UI 0.8.3 private renderer is resolved only through a guarded upvalue lookup from its public `getScaleTokens` export; required renderer/helper signatures are verified before any wrapper is installed.
- Party: the real upstream `drawParty` and `drawMonDetail` run first. Only the finished legacy four-cell stat text area is repainted as five cells: ATK / DEF / SPD / SPATK / SPDEF. Party list, icons, selected sprite, type, HP bar, moves/PP, frame, spacing, theme and interaction remain upstream-rendered.
- Summary page 1: the real upstream `drawSummary` runs first. Only the legacy SPECIAL row area is repainted as SP.ATK + SP.DEF; ID/OT and panel geometry remain at upstream coordinates.
- `ModernUI Override = OFF` leaves ordinary Modern UI Party/Summary output untouched. VANILLA Special mode likewise performs no split-stat repaint.
- Battle Party is gated separately by `ModernUI BattleWIP Override`; with that option OFF, the surgical Party row does not alter battle presentation.
- Hot-reload restoration prevents wrapper stacking.

## PASS — Modern Battle UI level-up correction contract (current code, gated by BattleWIP)

- Public-hook only: `ui.state.decorate` + `render.hud`; no foreign source replacement and no Modern UI private-function patch.
- Real-hook contract: Modern UI 0.8.3's priority-100 `ui.state.decorate` is executed beneath Special Stat Split's priority-200 observer. With experimental BATTLE UI (WIP) ON it replaces the exact source-owned split StatBox draw.
- Exact-identity guard: only replacement of Special Stat Split's own `splitStatBoxDraw` is treated as a candidate; an unrelated draw wrapper is not enough.
- Native-draw guard: the source split draw marks the frame when it actually executes. HIDE ORIGINAL UI OFF therefore produces no duplicate correction even while Modern UI's decorator remains installed.
- Default-off guard: turning BATTLE UI (WIP) OFF and running a fresh decoration pass restores the source split draw and retires the candidate; no correction overlay is produced.
- Hook priority/order contract: correction HUD is priority 200, calls downstream first, and paints only afterward.
- Exact-state guard: only the active `BattleState.StatBox` can trigger the correction.
- Split-mode guard: VANILLA Special produces no correction.
- Dependency guard: with Modern UI absent, no level-up compatibility hooks are installed.
- Correct visible rows: ATTACK / DEFENSE / SPEED / SP. ATK / SP. DEF; the correction card never emits a legacy SPECIAL row.
- Full 251-stat / 251-move / Crystal / save / frozen-upstream regression suite remains PASS.


## PASS — Modern UI override ownership / future-version guards (2.4.0)

- `ModernUI Override` exists as an exact-label toggle and defaults **true/ON**; OFF prevents ordinary Party/Summary ownership by Special Stat Split.
- `ModernUI BattleWIP Override` exists as an exact-label toggle and defaults **false/OFF**; OFF prevents battle Party ownership and produces no level-up correction card even when the real Modern UI 0.8.3 WIP battle decorator suppresses the native StatBox.
- BattleWIP Override ON retains the behavior-detected battle Party and level-up correction paths.
- The full ordinary-override ON/OFF × BattleWIP ON/OFF matrix passes against real Modern UI 0.8.3.
- A synthetic future Modern UI release number (for example 0.9.9) is deliberately rejected for the ordinary surgical shim even when it still advertises compatibility API v1; its UI is left untouched.
- A synthetic future Modern UI compatibility API v2 is also rejected and installs no unsupported compatibility hooks (fail closed).
