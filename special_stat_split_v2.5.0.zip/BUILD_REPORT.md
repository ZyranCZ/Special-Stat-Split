# Build report — v2.5.0

## 2.5.0 build baseline

The sole source is the final assistant-delivered `special_stat_split_v2.4.2.zip`, SHA-256 `c0e6c7fe4972e892b1f656fe31597e5cb3c753f7c98c1b8dc68ed0b894536dab`. Before editing, the package was freshly extracted and verified as `2.4.2` in both `manifest.json` and the `main.lua` header. No older test package was used.

This release adds the versioned API v1, diagnostics, deterministic link gameplay revision, regression coverage and documentation. It deliberately does not alter the established split-stat formulas, move-category datasets, save contract or Modern UI renderer geometry. The user confirmed the in-game functional/UI smoke. Dedicated two-peer link QA was intentionally waived as a release blocker and is not claimed as certified.

## Inherited 2.4.2 release contents

The v2.4.2 release keeps the completed test7 presentation behavior:

- **ModernUI Party Stats Layout = 2 ROWS** (default): `ATTACK / DEFENSE / SPEED`, then `SPEC. ATTACK / SPEC. DEFENSE`.
- **ModernUI Party Stats Layout = 1 ROW**: compact `ATK / DEF / SPD / SPATK / SPDEF`.
- Party choices use one shared adaptive font scale calculated from the live panel width.
- Summary is intentionally independent of the Party toggle and always places `SP. ATTACK` and `SP. DEFENSE` on separate rows on desktop and mobile, with ID/OT moved below using Modern UI's native fallback data.

## Forward compatibility

Modern UI ordinary Party/Summary compatibility is capability-gated rather than version-number-gated. 0.8.3 and 0.8.4 are verified implementations; a compatible future version number (tested synthetically as 0.9.9) continues to install the shim. Missing/incompatible API or renderer capabilities fail closed.

## Automated verification

PASS against:

- 251/251 split-stat reference rows and 502/502 SpA/SpD values;
- 251/251 modern move categories;
- all Special/category configurations;
- standalone Move Category coexistence contracts;
- Crystal 251 contracts;
- Party/Summary layout and Modern UI capability guards;
- ModernUI Override ON/OFF, BattleWIP guards and VANILLA guards.

The test7 suite was run before promotion and the final suite was rerun after metadata/documentation conversion. The distributable ZIP keeps `manifest.json` and `main.lua` at archive root.
