# Changelog

## 1.0.1

- Added optional Pokédex Plus 1.3.0 Base Stats screen compatibility.
- GEN II mode now shows SP.ATK / SP.DEF and the six-stat BST on that page.
- VANILLA mode preserves the original Pokédex Plus screen unchanged.
- No battle, stat calculation, save, or Summary UI mechanics changed from 1.0.0.

## 1.0.0

First public release.

- Generation II Special Attack / Special Defense split for all 151 Kanto Pokémon.
- Special damage uses attacker Sp. Atk against defender Sp. Def while preserving the upstream Gen1Recomp damage formula.
- Physical damage path remains unchanged.
- Gen II behavior for Growth, Amnesia, Psychic's Special drop, X Special and shared Special Stat Exp.
- Transform copies both split stats and stages.
- Summary and level-up UI show separate Sp. Atk / Sp. Def.
- Vanilla-compatible save schema; derived split stats are not serialized into progress saves.
- VANILLA / GEN II restart-required option.
- Full reference, damage-oracle, Lua and frozen-upstream regression suite passed.
- In-game and normal-mod-stack smoke tests passed.
- Live two-peer link play is not yet manually tested.

### Known UI-only compatibility notes

- EXP Share Modes 1.0.0 custom bench level-up screen still displays legacy `SPECIAL`.
- Pokédex Plus 1.3.0 custom Base Stats screen still displays legacy `SPECIAL`.
