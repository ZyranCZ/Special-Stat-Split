# Verification Report — v1.0.1

## test2 loader fix

The first in-game smoke of `0.3.0-test1` failed before initialization because
`main.lua` used `require("lib.split_stats")`. Gen1Recomp's packaged mod loader
does not add the installed mod directory to the normal module search path.
`1.0.0` therefore embeds all runtime-owned helper code and the 151-row
Gen II Special table directly in `main.lua`. Test/reference files may still use
the split files, but the runtime entry has **zero mod-local `require()` calls**.


Frozen target: Gen1Recomp `v0.1.75`, commit
`60cf07fb0a1ffce0ec6d5d0d2f78a921a6d0b7da`.

## PASS — reference/data

- 151/151 Kanto species present exactly once.
- Full second-source cross-check against Bulbapedia's Gen II–V base-stat table: **151/151 species, 302/302 Sp. Atk/Sp. Def values**.
- Gen II–V sentinel stats: Butterfree 80/80, Alakazam 135/85, Chansey 35/105, Mewtwo 154/90.
- One shared `dvs.special` and one shared `statExp.special` feed both calculated split stats.
- Split stat formula matches frozen Gen1Recomp's non-HP stat formula.
- Gen II Stat Exp behavior verified against `pokecrystal`: the one shared Special Stat Exp bucket receives the defeated Pokémon's base Sp. Atk, not Sp. Def.

## PASS — independent battle oracle

- All stages `-6..+6` and clamp behavior.
- Exact floor-sensitive SpA/SpD damage vectors.
- Light Screen.
- Volcano Badge operand ordering under the deliberately preserved Gen1Recomp badge semantics.
- `gen1_faithful` critical-stage bypass.
- `modern_clean` critical-stage path.
- Physical control vector.

## PASS — real Lua contracts

- `main.lua` and helper Lua syntax execute under a real Lua runtime (`texlua`).
- GEN II runtime stub: stat attachment, special operand routing, physical transparency, error restoration, Experience, X Special, Growth, Amnesia, Psychic drop, Transform, save strip/restore, Summary labels and StatBox labels.
- VANILLA runtime stub: no split fields and untouched damage/save behavior.

## PASS — exact frozen upstream integration

The integration suite is run against exact frozen upstream source files and first verifies their SHA-256 hashes.

- Exact `Stats.lua`: stage table and stat calculation path.
- Exact `Damage.lua`: GEN II wrapper output equals the same upstream function with manual SpA/SpD operand substitution across neutral, staged, Light Screen, Volcano Badge, faithful-crit and modern-crit cases.
- Exact physical damage parity against the pre-patch frozen function.
- Exact `Experience.lua`: shared Special Stat Exp gain uses defeated Gen II base Sp. Atk.
- Exact `MoveEffects.lua`: Growth, Amnesia, Psychic drop, +6/-6 caps, Psychic secondary drop piercing Mist, Haze clearing both split stages, Transform stage/stat copy.
- Exact `ItemEffects.lua`: X Special -> Sp. Atk, +6 cap, Calcium shared Special Stat Exp recalculation, Rare Candy recalculation.
- Exact `SaveData.validate`: legacy party stat-table identity retained; stat-less box Pokémon gets calculated split stats; upstream HP clamp retained.
- Exact `SaveData.save`: derived SpA/SpD absent from the table handed to the serializer, legacy `special`, shared Special DV/Stat Exp and unrelated same-named fields retained; in-memory derived fields restored afterward.
- Exact `Pokemon.new`: newly generated Pokémon receive split stats.
- Exact `Evolution.apply`: evolved Pokémon recalculate split stats while preserving upstream evolution side effects.
- Exact frozen VANILLA parity: Stats, special damage, physical damage, Experience, X Special, Growth and Psychic remain legacy behavior.

## PASS — architecture audits

- Trainer AI does not directly calculate damage from the legacy Special stat, so no AI stat operand patch is needed.
- Link protocol serializes species/level/DVs/Stat Exp rather than calculated split stats; both peers reconstruct through `Stats.calc`. `affects_link=true` remains mandatory.
- Wild/new Pokémon, level-up, evolution, validation/box restoration and item recalculation all converge on wrapped `Stats.calc` / `Stats.ensure` paths.

## PASS — user in-game smoke on test3

The user reported that the requested `0.3.0-test3` in-game smoke tests worked. This closes the practical load/UI/battle/save smoke gate for the tested setup. The accepted Summary layout is intentionally unchanged in the public release.

## PUBLIC 1.0.1 STATUS

- User in-game smoke: **PASS**.
- User normal enabled-mod-stack smoke: **PASS**.
- Live two-peer link battle smoke: **NOT MANUALLY TESTED** and explicitly documented in README.
- Pokédex Plus 1.3.0 Base Stats UI compatibility is integrated and contract-tested. EXP Share Modes 1.0.0 remains the only known UI-only legacy `SPECIAL` label in its private bench level-up screen.

## Oracle notes

The independent oracle has already caught manual expected-value mistakes during development (for example, a hand-entered 60 that is exactly 61 under Gen I floor ordering). Production code was not changed for those cases; the expected vectors were corrected after independent recomputation. This is why release certification does not rely on visual HP-bar estimates.

## Transform regression fix retained from test3

- `Damage.compute` now derives split fields only when they are missing from `curStats`.
- A transformed battler therefore keeps the copied target Sp. Atk / Sp. Def for subsequent special damage.
- Exact frozen-upstream regression covers transformed attacker and transformed defender paths.
- Summary rendering is intentionally unchanged from test2 after the in-game layout was accepted.

## Public 1.0.1 packaging gate

- Full `tools/run_all.sh` against frozen Gen1Recomp core: **PASS**.
- Runtime mechanics are unchanged from the user-tested `1.0.0-rc1` / `0.3.0-test3`: **PASS**.
- Manifest public version `1.0.1`: **PASS**.
- ZIP integrity: checked during packaging.


## 1.0.1 compatibility gate

- Pokédex Plus optional dependency ordering: PASS (manifest + loader contract)
- PokedexPlusStats screen patch present only when dependency is available: PASS
- GEN II base stats page SP.ATK/SP.DEF/BST contract: PASS
- VANILLA Pokédex Plus factory passthrough: PASS
- Core battle/stat/save code inherited unchanged from tested 1.0.0 baseline.
