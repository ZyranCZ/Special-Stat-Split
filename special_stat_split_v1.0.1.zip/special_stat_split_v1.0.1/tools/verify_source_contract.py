#!/usr/bin/env python3
"""Static source-contract checks for the packaged mod.

Not a substitute for an in-engine run; this prevents accidental removal of the
specific delegation/restoration/UI invariants the design relies on.
"""
from pathlib import Path
import json, re

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'main.lua').read_text(encoding='utf-8')
MANIFEST = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))

assert MANIFEST['id'] == 'special_stat_split'
assert MANIFEST['version'] == '1.0.1'
assert MANIFEST['api'] == 2
assert MANIFEST['game_version'] == '>=0.1.75 <0.1.76'
assert 'pokedex_plus' in MANIFEST.get('optional_dependencies', [])
assert MANIFEST.get('affects_link') is True
assert 'engine_internals' in MANIFEST.get('permissions', [])

required = [
    'category ~= "special"',
    'return state.originalDamage(ruleset, attacker, defender, move, opts)',
    'local function ensureCurrentSplit(b)',
    'if b.curStats.specialAttack == nil or b.curStats.specialDefense == nil then',
    'ensureCurrentSplit(attacker)',
    'ensureCurrentSplit(defender)',
    'acs.special = acs.specialAttack or acs.special',
    'dcs.special = dcs.specialDefense or dcs.special',
    'ast.special = ast.specialAttack or 0',
    'dst.special = dst.specialDefense or 0',
    'local result = pack(pcall(state.originalDamage',
    'acs.special = save.acsSpecial',
    'dcs.special = save.dcsSpecial',
    'ast.special = save.astSpecial',
    'dst.special = save.dstSpecial',
    'SummaryMenu.draw = function(self)',
    'BattleState.StatBox.draw = function(self)',
    '{ "SPATK", st.specialAttack or st.special }',
    '{ "SPDEF", st.specialDefense or st.special }',
    '{ "SP.ATK", st.specialAttack or st.special }',
    '{ "SP.DEF", st.specialDefense or st.special }',
    'aliasStageRun("SPECIAL_UP1_EFFECT", "user", "specialAttack")',
    'aliasStageRun("SPECIAL_UP2_EFFECT", "user", "specialDefense")',
    'aliasStageRun("SPECIAL_DOWN_SIDE_EFFECT", "target", "specialDefense")',
    'stages.specialAttack = stages.special or 0',
    'ctx.user.curStats.specialAttack',
    'ctx.user.curStats.specialDefense',
    'defeatedDef.baseStats.special = row.spa',
    'SaveData.save = function(data, mods)',
    'mod.exports.getSpecialBaseStats = function(species)',
    'state.derivedStats[value]',
    '{ \"specialAttack\", \"specialDefense\" }',
    'local result = pack(pcall(state.originalSave, data, mods))',
]
for text in required:
    assert text in MAIN, f'missing source contract: {text}'


# Pixel-geometry release guard for the frozen 8px tile font. These assertions
# keep every glyph inside the white interior rather than over the box border.
# Summary: box (0,8,10,10) -> interior x 8..71, y 72..135.
summary_label_x, summary_value_x = 8, 48
summary_first_y, summary_step = 72, 14
assert summary_label_x + 5 * 8 - 1 <= 47
assert summary_value_x + 3 * 8 - 1 <= 71
assert summary_first_y >= 72
assert summary_first_y + 4 * summary_step + 7 <= 135
assert 'local y = 72 + (i - 1) * 14' in MAIN
assert 'Font.draw(("%3d"):format(r[2] or 0), 48, y)' in MAIN
# Level-up: box (9,2,11,10) -> interior x 80..151, y 24..87.
stat_label_x, stat_value_x = 80, 128
stat_first_y, stat_step = 24, 14
assert stat_label_x + 6 * 8 - 1 <= 127
assert stat_value_x + 3 * 8 - 1 <= 151
assert stat_first_y >= 24
assert stat_first_y + 4 * stat_step + 7 <= 87
assert 'local y = 24 + (i - 1) * 14' in MAIN
assert 'Font.draw(("%3d"):format(r[2] or 0), 128, y)' in MAIN

# The mod must not redefine the upstream shared DV/StatExp ordering.
assert 'Stats.ORDER =' not in MAIN
assert 'dvs.specialAttack' not in MAIN and 'dvs.specialDefense' not in MAIN
assert 'statExp.specialAttack' not in MAIN and 'statExp.specialDefense' not in MAIN

# All three legacy Special move effects must be patched once each.
for effect in ('SPECIAL_UP1_EFFECT','SPECIAL_UP2_EFFECT','SPECIAL_DOWN_SIDE_EFFECT'):
    assert MAIN.count(f'aliasStageRun("{effect}"') == 1

# Vanilla mode remains a load-time option and all global wrappers consult state.active.
assert 'default = "gen2"' in MAIN
assert 'local active = tostring(mod.options:get("mode") or "gen2") == "gen2"' in MAIN
assert MAIN.count('state.active') >= 8


# Packaged mod runtime must be self-contained. Gen1Recomp loads the manifest
# entry but does not prepend a mod's own directory to the require path.
assert not re.search(r'(?m)^[^\n-]*require\([\"\'](?:lib|data)\.', MAIN)
assert 'local GEN2_SPECIAL_BY_ID = {' in MAIN
assert len(re.findall(r'^  [A-Z0-9_]+ = \{ dex = \d+, spa = \d+, spd = \d+ \},$', MAIN, re.M)) == 151

print('PACKAGED MOD LOADER CONTRACT: PASS')
print('MANIFEST CONTRACT: PASS')
print('DAMAGE DELEGATION/RESTORE CONTRACT: PASS')
print('SHARED SPECIAL DV/STAT EXP CONTRACT: PASS')
print('MOVE EFFECT ROUTING CONTRACT: PASS')
print('SUMMARY + LEVEL-UP UI CONTRACT: PASS')
print('SAVE SCHEMA STRIP/RESTORE CONTRACT: PASS')
print('VANILLA DELEGATION GUARDS: PASS')

assert 'PokedexPlusStats' in MAIN
assert 'SP.ATK' in MAIN and 'SP.DEF' in MAIN
