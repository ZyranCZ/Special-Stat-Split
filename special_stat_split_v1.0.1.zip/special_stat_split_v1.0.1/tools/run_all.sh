#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 tools/verify_reference.py
python3 tools/verify_second_source.py
python3 tools/verify_battle_math.py
python3 tools/verify_source_contract.py
texlua tests/reference_contract.lua
texlua tests/runtime_stub_contract.lua gen2
texlua tests/runtime_stub_contract.lua vanilla
if [[ $# -ge 1 ]]; then
  FROZEN="$1"
  python3 tools/verify_frozen_sources.py "$FROZEN"
  texlua tests/frozen_upstream_contract.lua "$FROZEN" gen2
  texlua tests/frozen_upstream_contract.lua "$FROZEN" vanilla
  texlua tests/frozen_save_contract.lua "$FROZEN"
  texlua tests/frozen_lifecycle_contract.lua "$FROZEN"
else
  echo 'NOTE: frozen upstream integration skipped; pass Gen1Recomp 60cf07f root to run it.'
fi
