-- Headless runtime contracts for SPECIAL STAT SPLIT.
-- Runs under texlua with minimal Gen1Recomp stubs. No LÖVE window required.

package.path = './?.lua;./?/init.lua;' .. package.path

local MODE = arg[1] or 'gen2'
local function expect(cond, msg)
  if not cond then error('ASSERTION FAILED: ' .. tostring(msg), 2) end
end
local function deepcopy(t)
  if type(t) ~= 'table' then return t end
  local out = {}
  for k,v in pairs(t) do out[k] = deepcopy(v) end
  return out
end

_G.love = { graphics = {
  setColor = function() end,
  rectangle = function() end,
} }

local fontCalls = {}
local Font = {
  draw = function(text, x, y) fontCalls[#fontCalls+1] = tostring(text) end,
  drawBox = function() end,
  width = function(text) return #tostring(text) * 8 end,
}
local Strings = setmetatable({ source = function(s) return s end }, {
  __call = function(_, fmt, ...)
    if select('#', ...) == 0 then return tostring(fmt) end
    return string.format(tostring(fmt), ...)
  end,
})

local Stats = {}
function Stats.calc(def, level, dvs, statExp)
  local b = def.baseStats or {}
  local dv = dvs or {}
  local ex = statExp or {}
  local function calc(base, key)
    local ev = math.floor(math.min(255, math.ceil(math.sqrt(ex[key] or 0))) / 4)
    return math.floor(((base + (dv[key] or 0)) * 2 + ev) * level / 100) + 5
  end
  return {
    hp = 100,
    attack = calc(b.attack or 50, 'attack'),
    defense = calc(b.defense or 50, 'defense'),
    speed = calc(b.speed or 50, 'speed'),
    special = calc(b.special or 50, 'special'),
  }
end
function Stats.ensure(def, mon)
  mon.stats = mon.stats or Stats.calc(def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
  return mon
end

local damageSeen = {}
local Damage = {}
function Damage.compute(ruleset, attacker, defender, move, opts)
  damageSeen[#damageSeen+1] = {
    a = attacker.curStats.special,
    d = defender.curStats.special,
    as = attacker.stages and attacker.stages.special,
    ds = defender.stages and defender.stages.special,
    physical = move.category == 'physical',
  }
  if opts and opts.throw then error('forced damage failure') end
  return attacker.curStats.special - defender.curStats.special + 1000,
         attacker.stages.special or 0,
         defender.stages.special or 0
end
Damage.BADGE_BOOSTS = { VOLCANO = 'special' }

local Experience = {}
local expSeen
function Experience.apply(data, mon, defeatedDef, ...)
  expSeen = defeatedDef.baseStats.special
  return true, {'EXP OK'}
end

local ItemEffects = {}
function ItemEffects.use(data, saveData, itemId, target, battle)
  if itemId == 'X_SPECIAL' then
    local s = battle.player.stages
    s.special = math.min(6, (s.special or 0) + 1)
    return true, {"PLAYER's\nSPECIAL rose!"}
  end
  return true, {'ITEM OK'}
end

local function statEffect(delta, side, chance)
  return function(ctx)
    local who = side == 'target' and ctx.target or ctx.user
    if chance and ctx.battle.rng(0,255) >= chance then return {} end
    who.stages.special = math.max(-6, math.min(6, (who.stages.special or 0) + delta))
    return {"MON's\nSPECIAL " .. (delta > 0 and 'rose!' or 'fell!')}
  end
end
local MoveEffects = { RECORDS = {} }
MoveEffects.RECORDS.SPECIAL_UP1_EFFECT = { run = statEffect(1, 'user') }
MoveEffects.RECORDS.SPECIAL_UP2_EFFECT = { run = statEffect(2, 'user') }
MoveEffects.RECORDS.SPECIAL_DOWN_SIDE_EFFECT = { run = statEffect(-1, 'target', 85) }
MoveEffects.RECORDS.TRANSFORM_EFFECT = { run = function(ctx)
  ctx.user.curStats = {
    hp = ctx.user.mon.stats.hp,
    attack = ctx.target.curStats.attack,
    defense = ctx.target.curStats.defense,
    speed = ctx.target.curStats.speed,
    special = ctx.target.curStats.special,
  }
  ctx.user.stages = deepcopy(ctx.target.stages)
  return {'TRANSFORMED'}
end }

local SummaryMenu = { draw = function() end }
local BattleState = { StatBox = { draw = function() end } }
local SaveData = {}
local saveSeen
function SaveData.save(data, mods)
  saveSeen = {
    trackedSpa = data.party[1].stats.specialAttack,
    trackedSpd = data.party[1].stats.specialDefense,
    unrelatedSpa = data.unrelated.specialAttack,
    unrelatedSpd = data.unrelated.specialDefense,
  }
  if data.forceSaveError then error('forced save failure') end
  return true, 'saved'
end

local TypeChart = { category = function(typeId)
  return typeId == 'PSYCHIC' and 'special' or 'physical'
end }

local stubs = {
  ['src.pokemon.Stats'] = Stats,
  ['src.battle.Damage'] = Damage,
  ['src.battle.Experience'] = Experience,
  ['src.inventory.ItemEffects'] = ItemEffects,
  ['src.battle.MoveEffects'] = MoveEffects,
  ['src.ui.SummaryMenu'] = SummaryMenu,
  ['src.battle.BattleState'] = BattleState,
  ['src.render.Font'] = Font,
  ['src.core.Strings'] = Strings,
  ['src.core.SaveData'] = SaveData,
  ['src.battle.TypeChart'] = TypeChart,
}
for name, value in pairs(stubs) do
  package.preload[name] = function() return value end
end

local patchedEffects = {}
local patchedScreens = {}
local originalPokedexStats = {
  new = function(game, opts)
    local species = (opts and (opts.species or opts[1])) or 'ALAKAZAM'
    return {
      game = game, species = species, name = species,
      stats = { hp=55, attack=50, defense=45, speed=120, special=135, total=405 },
      draw = function(self)
        Font.draw('BASE STATS', 8, 16)
        Font.draw('SPECIAL', 16, 100)
      end,
    }
  end,
}
local optionMode = MODE == 'vanilla' and 'vanilla' or 'gen2'
local mod = {
  options = {
    define = function() end,
    get = function(_, key) if key == 'mode' then return optionMode end end,
  },
  content = {
    move_effects = {
      patch = function(_, id, record) patchedEffects[id] = record end,
    },
    screens = {
      get = function(_, id)
        if id == 'PokedexPlusStats' then return originalPokedexStats end
      end,
      patch = function(_, id, record) patchedScreens[id] = record end,
    },
  },
  find = function(id)
    if id == 'pokedex_plus' then return { id=id, version='1.3.0', exports={} } end
  end,
  log = { info=function() end, warn=function() end, error=function() end },
  exports = {},
}

local init = assert(loadfile('main.lua'))()
init(mod)

local alakazam = {
  id = 'ALAKAZAM', dex = 65,
  baseStats = { attack=50, defense=45, speed=120, special=135 },
}
local chansey = {
  id = 'CHANSEY', dex = 113,
  baseStats = { attack=5, defense=5, speed=50, special=105 },
}
local dvs = { attack=7, defense=7, speed=7, special=10 }
local statExp = { attack=1000, defense=1000, speed=1000, special=10000 }

if optionMode == 'vanilla' then
  expect(mod.exports.getSpecialBaseStats('ALAKAZAM') == nil,
         'VANILLA inter-mod base-stat export must be inactive')
  local stats = Stats.calc(alakazam, 50, dvs, statExp)
  expect(stats.specialAttack == nil and stats.specialDefense == nil,
         'VANILLA Stats.calc must not add split fields')
  local a = { curStats={special=111}, stages={special=2} }
  local d = { curStats={special=77}, stages={special=-1} }
  Damage.compute({}, a, d, {category='special'})
  local last = damageSeen[#damageSeen]
  expect(last.a == 111 and last.d == 77 and last.as == 2 and last.ds == -1,
         'VANILLA damage must delegate untouched')
  local save = { party={{stats={special=99}}}, unrelated={specialAttack=12,specialDefense=13} }
  SaveData.save(save, {})
  expect(saveSeen.unrelatedSpa == 12 and saveSeen.unrelatedSpd == 13,
         'VANILLA save delegate')
  expect(patchedScreens.PokedexPlusStats ~= nil,
         'Pokédex Plus screen wrapper should be registered when dependency is present')
  local vanillaDex = patchedScreens.PokedexPlusStats.new(
    {data={pokemon={ALAKAZAM=alakazam}}}, {species='ALAKAZAM'})
  expect(vanillaDex.stats.specialAttack == nil and vanillaDex.stats.specialDefense == nil,
         'VANILLA Pokédex Plus screen remains untouched')
  print('special_stat_split runtime stub (VANILLA): PASS')
  os.exit(0)
end

-- 1) Real Lua stat attachment with shared Special DV/Stat Exp.
local exported = mod.exports.getSpecialBaseStats('ALAKAZAM')
expect(exported and exported.specialAttack == 135 and exported.specialDefense == 85,
       'GEN II inter-mod base-stat export')
local astats = Stats.calc(alakazam, 50, dvs, statExp)
local cstats = Stats.calc(chansey, 50, dvs, statExp)
expect(astats.specialAttack ~= nil and astats.specialDefense ~= nil, 'split fields attached')
expect(astats.specialAttack > astats.specialDefense, 'Alakazam SpA > SpD')
expect(cstats.specialDefense > cstats.specialAttack, 'Chansey SpD > SpA')

-- 2) Special damage gets SpA/SpD + separate stages; legacy fields restore.
local attacker = {
  mon={level=50,dvs=dvs,statExp=statExp}, def=alakazam,
  curStats=astats, stages={special=4,specialAttack=2},
}
local defender = {
  mon={level=50,dvs=dvs,statExp=statExp}, def=chansey,
  curStats=cstats, stages={special=-4,specialDefense=-1},
}
local oldASpecial, oldDSpecial = astats.special, cstats.special
local out, as, ds = Damage.compute({}, attacker, defender, {category='special'})
local last = damageSeen[#damageSeen]
expect(last.a == astats.specialAttack and last.d == cstats.specialDefense,
       'special damage uses attacker SpA / defender SpD')
expect(last.as == 2 and last.ds == -1, 'special damage uses separate stages')
expect(astats.special == oldASpecial and cstats.special == oldDSpecial,
       'legacy calculated special restored')
expect(attacker.stages.special == 4 and defender.stages.special == -4,
       'legacy special stages restored')

-- Error path must restore too.
local ok = pcall(Damage.compute, {}, attacker, defender, {category='special'}, {throw=true})
expect(not ok, 'forced damage error propagated')
expect(astats.special == oldASpecial and cstats.special == oldDSpecial,
       'damage error path restores calculated special')
expect(attacker.stages.special == 4 and defender.stages.special == -4,
       'damage error path restores special stages')

-- 3) Physical path does not substitute split stats.
Damage.compute({}, attacker, defender, {category='physical'})
last = damageSeen[#damageSeen]
expect(last.a == oldASpecial and last.d == oldDSpecial and last.physical,
       'physical damage delegates with untouched legacy special')

-- 4) Experience shared Special bucket is awarded from defeated base SpA.
Experience.apply({}, {}, chansey, 50, false, 1, false)
expect(expSeen == 35, 'Gen II shared Special Stat Exp gain uses defeated base SpA')
expect(chansey.baseStats.special == 105, 'Experience wrapper restores species legacy special')

-- 5) X Special -> Sp. Atk only; legacy stage preserved; message relabelled.
local battle = { player={stages={special=3,specialAttack=1}} }
local okItem, msgs = ItemEffects.use({}, {}, 'X_SPECIAL', nil, battle)
expect(okItem == true, 'X Special original result preserved')
expect(battle.player.stages.specialAttack == 2, 'X Special increments SpA stage')
expect(battle.player.stages.special == 3, 'X Special legacy stage restored')
expect(msgs[1]:find('SP%. ATK') ~= nil, 'X Special message says SP. ATK')

-- 6) Move-effect routing.
local user = { stages={special=5,specialAttack=0,specialDefense=0} }
local target = { stages={special=-5,specialDefense=0} }
local ctx = { user=user, target=target, battle={rng=function() return 0 end} }
local growthMsg = patchedEffects.SPECIAL_UP1_EFFECT.run(ctx)
expect(user.stages.specialAttack == 1 and user.stages.special == 5,
       'Growth routes to SpA')
expect(growthMsg[1]:find('SP%. ATK') ~= nil, 'Growth message relabelled')
local amnesiaMsg = patchedEffects.SPECIAL_UP2_EFFECT.run(ctx)
expect(user.stages.specialDefense == 2 and user.stages.special == 5,
       'Amnesia routes to SpD')
expect(amnesiaMsg[1]:find('SP%. DEF') ~= nil, 'Amnesia message relabelled')
local psychicMsg = patchedEffects.SPECIAL_DOWN_SIDE_EFFECT.run(ctx)
expect(target.stages.specialDefense == -1 and target.stages.special == -5,
       'Psychic side drop routes to SpD')
expect(psychicMsg[1]:find('SP%. DEF') ~= nil, 'Psychic drop message relabelled')

-- 7) Transform copies both current split stats and split stages via existing stage copy.
local tUser = { mon={stats={hp=123}}, curStats={special=1}, stages={} }
local tTarget = {
  curStats={attack=1,defense=2,speed=3,special=4,specialAttack=155,specialDefense=88},
  stages={specialAttack=2,specialDefense=-2}, curTypes={'PSYCHIC'}, curMoves={},
  mon={species='ALAKAZAM'}, name='TARGET',
}
local tctx = {user=tUser,target=tTarget,battle={speciesSprite=function() return nil end}}
patchedEffects.TRANSFORM_EFFECT.run(tctx)
expect(tUser.curStats.specialAttack == 155 and tUser.curStats.specialDefense == 88,
       'Transform copies split current stats')
expect(tUser.stages.specialAttack == 2 and tUser.stages.specialDefense == -2,
       'Transform keeps copied split stages')

-- Transform -> damage regression.  A transformed curStats table already owns
-- copied SpA/SpD and must not be overwritten from the user's original species.
tUser.mon.level = 50; tUser.mon.dvs = dvs; tUser.mon.statExp = statExp
tUser.def = {id='ALAKAZAM',dex=65,baseStats={hp=55,attack=50,defense=45,speed=120,special=135}}
tUser.curTypes = {'PSYCHIC'}; tUser.badges = {}
tTarget.mon.level = 50; tTarget.mon.dvs = dvs; tTarget.mon.statExp = statExp
tTarget.def = {id='CHANSEY',dex=113,baseStats={hp=250,attack=5,defense=5,speed=50,special=105}}
tTarget.badges = {}
local copiedSpa = tUser.curStats.specialAttack
Damage.compute({}, tUser, tTarget, {id='PSYCHIC',type='PSYCHIC',category='special',power=90}, {})
expect(tUser.curStats.specialAttack == copiedSpa, 'Transform copied SpA survives subsequent Damage.compute')

-- 8) Save strip/restore: tracked stats removed on disk, unrelated fields untouched.
local mon = {species='ALAKAZAM',level=50,dvs=dvs,statExp=statExp,stats=astats}
local save = {party={mon}, unrelated={specialAttack=12,specialDefense=13}}
local s1, s2 = SaveData.save(save, {})
expect(s1 == true and s2 == 'saved', 'SaveData return values preserved')
expect(saveSeen.trackedSpa == nil and saveSeen.trackedSpd == nil,
       'derived split fields absent during serialization')
expect(saveSeen.unrelatedSpa == 12 and saveSeen.unrelatedSpd == 13,
       'unrelated same-named fields preserved')
expect(astats.specialAttack ~= nil and astats.specialDefense ~= nil,
       'derived fields restored after save')

save.forceSaveError = true
local saveOk = pcall(SaveData.save, save, {})
expect(not saveOk, 'forced save error propagated')
expect(astats.specialAttack ~= nil and astats.specialDefense ~= nil,
       'save error path restores derived fields')

-- 9) UI wrappers render both labels while preserving original screens.
fontCalls = {}
local game = {data={pokemon={ALAKAZAM=alakazam}}}
SummaryMenu.draw({page=1,mon=mon,game=game})
local joined = table.concat(fontCalls, '|')
expect(joined:find('SPATK') and joined:find('SPDEF'), 'Summary renders both compact split labels')
fontCalls = {}
BattleState.StatBox.draw({mon=mon,game=game})
joined = table.concat(fontCalls, '|')
expect(joined:find('SP%.ATK') and joined:find('SP%.DEF'), 'Level-up StatBox renders both split labels')

-- 10) Optional Pokédex Plus Base Stats screen shows split bases and Gen II BST.
expect(patchedScreens.PokedexPlusStats ~= nil, 'Pokédex Plus screen compatibility patched')
local dexGame = { data={ pokemon={ ALAKAZAM=alakazam } } }
local dexScreen = patchedScreens.PokedexPlusStats.new(dexGame, {species='ALAKAZAM'})
expect(dexScreen.stats.specialAttack == 135 and dexScreen.stats.specialDefense == 85,
       'Pokédex Plus screen receives Gen II SpA/SpD bases')
expect(dexScreen.stats.total == 490, 'Pokédex Plus TOTAL uses six Gen II battle stats')
fontCalls = {}
dexScreen:draw()
joined = table.concat(fontCalls, '|')
expect(joined:find('SP%.ATK') and joined:find('SP%.DEF'),
       'Pokédex Plus draw renders SP.ATK and SP.DEF')

print('special_stat_split runtime stub (GEN II): PASS')
