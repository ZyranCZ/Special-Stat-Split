# Special Stat Split 1.0.0 — Testing notes

Public 1.0.0 passed the automated release gate plus user in-game and normal-mod-stack smoke testing.

Recommended post-install smoke:

1. Set `SPECIAL STATS (RESTART)` to `GEN II (SP. ATK / SP. DEF)`.
2. Save settings and restart Gen1Recomp.
3. Open a Pokémon Summary and confirm separate `SPATK` / `SPDEF` values.
4. Use one physical and one special attack.
5. Save, fully restart, reload, and re-open the same Pokémon.
6. Optionally switch to `VANILLA`, save + restart, and confirm the legacy single `SPECIAL` display returns.

Live two-peer link play was not manually smoke-tested for 1.0.0.
