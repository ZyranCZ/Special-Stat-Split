# Special Stat Split

Generation II-style **Special Attack / Special Defense** split for **Gen1Recomp**.

This mod splits the original Generation I `SPECIAL` stat into separate **Sp. Atk** and **Sp. Def** stats while deliberately keeping the **Gen I / Gen II type-based physical/special move categories**.

It does **not** implement the Generation IV per-move physical/special split.

> **Any option change requires save + restart.**

## Target

Built and verified for:

`Gen1Recomp v0.1.75 / commit 60cf07fb0a1ffce0ec6d5d0d2f78a921a6d0b7da`

## Features

- Gen II–V **Sp. Atk / Sp. Def base stats** for all 151 Kanto Pokémon.
- One shared **Special DV** and one shared **Special Stat Exp**, matching Generation II.
- Special damage uses **attacker Sp. Atk → defender Sp. Def**.
- Physical damage remains on the original **Attack → Defense** path.
- The original Gen1Recomp damage formula, RNG, STAB, type handling and rulesets are preserved.
- **Growth** → Sp. Atk +1.
- **Amnesia** → Sp. Def +2.
- **Psychic** secondary Special drop → Sp. Def -1.
- **X Special** → Sp. Atk +1.
- **Transform** copies both split current stats and split stages.
- **Haze** clears both split stat stages through the normal upstream stage reset.
- **Calcium** continues to increase the single shared Special Stat Exp and recalculates both stats.
- **Rare Candy**, level-up and evolution recalculate both split stats.
- Summary screen displays **SPATK / SPDEF**.
- Level-up StatBox displays **SP.ATK / SP.DEF**.
- Existing saves remain compatible; derived SpA/SpD fields are not written into the vanilla progress-save schema.
- `VANILLA` mode delegates back to original Gen1Recomp Special behavior.

## Option

### SPECIAL STATS (RESTART)

- **VANILLA** — original Generation I single `SPECIAL` stat.
- **GEN II (SP. ATK / SP. DEF)** — enables the Generation II Special split.

Default: **GEN II**

After changing this option, save the setting and restart Gen1Recomp.

## What remains Generation I / II-style

Move categories are still determined by type, exactly as in Generation I and II.

For example, Fire, Water, Electric and Psychic moves remain special, while Normal, Fighting and Ground moves remain physical.

This mod only changes which stats special moves use:

`SPECIAL → attacker SP. ATK / defender SP. DEF`

## Save compatibility

Generation II still used one shared Special DV and one shared Special Stat Exp for both Sp. Atk and Sp. Def. This mod follows the same model.

The mod therefore does not add new DV or Stat Exp fields to your Pokémon. Derived SpA/SpD values are recalculated from the existing Special DV/Stat Exp and are stripped before Gen1Recomp serializes the vanilla progress save.

## Verification

The release was tested using several independent layers:

1. 151/151 species and **302/302 SpA/SpD values** cross-checked against Gen II–V reference data.
2. Independent damage oracle with exact floor-sensitive test vectors.
3. Real Lua contract tests.
4. Integration tests against exact frozen Gen1Recomp v0.1.75 source modules verified by SHA-256.
5. In-game smoke testing, including Summary UI, battle flow and save/reload.
6. Normal enabled-mod-stack smoke testing.

Automated coverage includes special and physical damage, stat stages -6…+6, Light Screen, critical-hit rulesets, Growth, Amnesia, Psychic, X Special, Haze, Transform, Calcium, Rare Candy, Stat Exp, evolution, old-save loading and VANILLA parity.

See `VERIFICATION.md` for details.

## Compatibility notes

- **Pokédex Plus 1.3.0** — supported. In GEN II mode its Base Stats page shows SP.ATK / SP.DEF and the six-stat BST; VANILLA mode leaves its original page untouched.
- **EXP Share Modes 1.0.0** — its private bench level-up display still shows the legacy `SPECIAL` label. This is cosmetic only and does not bypass the underlying split mechanics.

### Link battles

The mod declares `affects_link = true`. The link protocol path was audited and reconstructs calculated stats from species, level, DVs and Stat Exp on both peers. However, a live two-peer link battle has **not** been manually smoke-tested for this release.

## Version

**1.0.1**

## Gen1Recomp

https://github.com/bryanthaboi/gen1recomp

