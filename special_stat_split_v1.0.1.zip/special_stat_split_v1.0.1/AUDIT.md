# SPECIAL audit — Gen1Recomp 60cf07f

Status legend: ✅ implemented + automated contract, 🟡 requires real-game smoke/visual test, 🔒 deliberately unchanged.

| Area | Frozen upstream | Split behavior | Status |
|---|---|---|---|
| `Stats.ORDER` | hp/atk/def/speed/special | unchanged for shared Stat Exp schema | 🔒 |
| `Stats.randomDVs` | one Special DV | one shared Special DV | 🔒 |
| `Stats.calc` | one calculated Special | adds derived Sp. Atk + Sp. Def | ✅ |
| `Stats.ensure` | preserves existing stat table / derives box stats | lazily adds split fields without replacing legacy table | ✅ |
| `Damage.compute` | Special vs Special | attacker SpA vs defender SpD via temporary alias | ✅ |
| Physical damage | Attack vs Defense | exact upstream path | ✅ |
| Stage multipliers | legacy stat stage table | same table, independent SpA/SpD stage keys | ✅ |
| Critical hits | ruleset-specific stage behavior | same behavior on split operands | ✅ |
| Light Screen | doubles special defense operand | doubles SpD operand | ✅ / 🟡 smoke |
| Volcano Badge | legacy Special x9/8 | preserved hybrid semantics: attack-side SpA / defense-side SpD | ✅ documented |
| Growth | Special +1 | Sp. Atk +1 | ✅ |
| Amnesia | Special +2 | Sp. Def +2 | ✅ |
| Psychic secondary | Special -1 | Sp. Def -1; still pierces Mist | ✅ |
| X Special | Special +1 | Sp. Atk +1 | ✅ |
| Calcium | shared Special Stat Exp | unchanged shared bucket; both split stats recalc | ✅ |
| Rare Candy / level-up | `Stats.calc` | both split stats recalc | ✅ |
| Stat Exp gain | defeated base Special | defeated Gen II base Sp. Atk | ✅ |
| Transform | copies legacy Special + stages | adds SpA/SpD and split stages | ✅ / 🟡 smoke |
| Haze | replaces entire stage tables | clears both split stage keys naturally | ✅ |
| Summary screen | four stat rows | compact five-row ATK/DEF/SPEED/SPATK/SPDEF | ✅ code / 🟡 visual |
| Level-up StatBox | four rows | compact five-row split display | ✅ code / 🟡 visual |
| Progress save | serializes full mon table | derived split fields stripped before serializer | ✅ |
| Old save validation | existing stats preserved; box stats derived | legacy table identity kept + split fields attached | ✅ |
| `Pokemon.new` | calls `Stats.calc` | new/wild mons get split stats | ✅ |
| Evolution | calls `Stats.calc` | evolved mons get recalculated split stats | ✅ |
| Trainer AI | no direct Special damage operand | no patch required | 🔒 |
| Link protocol | sends DV/Stat Exp, reconstructs stats | deterministic through wrapped `Stats.calc`; gameplay mod fingerprint required | ✅ audit / 🟡 live link |
| VANILLA mode | baseline | delegates exact frozen behavior | ✅ |

## Save-schema finding

Frozen `SaveData.save` serializes the complete progress table (minus `options`), including `mon.stats`. Therefore simply adding permanent `specialAttack` / `specialDefense` fields would silently change the progress-save structure. The mod tracks only stat tables it derived, removes those two fields during the exact upstream `SaveData.save` call, and restores them immediately afterward, including the error path. Exact frozen serializer-contract testing verifies the fields are absent at serialization time.

## Gen II Stat Exp finding

`pokecrystal` keeps six base stats but only five Stat Exp fields. Its experience loop iterates the first five base-stat entries: HP, Attack, Defense, Speed, Special Attack. Therefore the single Special Stat Exp bucket receives defeated base Sp. Atk; Sp. Def does not have a separate Stat Exp bucket. The implementation mirrors this directly.
