# Compatibility audit — development build

Static audit performed against the mod packages supplied alongside this project.
This is not a substitute for a live Gen1Recomp smoke test.

## No direct conflict found

- **STEEL/FAIRY AND TYPING CHARTS** — type/species typing changes only; no overlap with split-stat engine wrappers.
- **Autofire AB** — input layer only.
- **Dynamic Scaling 1.0.2** — wraps `BattleState.newTrainer`; Special Stat Split does not.
- **PC Grid UI 1.0.3** — calls `Stats.ensure`; this naturally receives split stats from our wrapper.
- **PokePCFollowers 0.0.3** — wraps `BattleState.newWild`; new Pokémon still converge on wrapped `Pokemon.new` / `Stats.calc`.
- **Wilds of Kanto 1.5.0** — audited Special-related path only reads `Stats.isShiny`; no split-stat conflict found.
- **Useful Move Info 1.4.0** — wraps `BattleState.update`; no overlap with damage/stat wrappers.
- **Modern Bag 1.5.0** — its `SPECIAL` labels refer to move damage class, not the Pokémon Special stat.
- Other supplied data/QoL mods showed no direct reads/writes of the legacy Special stat in the scanned Lua sources.

## Functional compatibility, UI mismatch

### EXP Share Modes 1.0.0

Its EXP distribution calls the shared `Experience.apply`, so split-stat calculation and
Stat Exp behavior still pass through Special Stat Split correctly. However, the mod owns a
**private local level-up StatBox** that explicitly draws `SPECIAL = stats.special`.

Result while both mods are enabled:
- battle/stat mechanics: expected compatible;
- normal Gen1Recomp level-up window: split UI;
- EXP Share Modes' custom bench level-up window: still shows legacy `SPECIAL`.

This cannot be cleanly patched through its public exports because the StatBox class is local
to that mod. A dedicated compatibility change in EXP Share Modes is preferable to a global
UI interception hack.

### Pokédex Plus 1.3.0

Its base-stat page reads `def.baseStats.special` directly and locally renders a single
`SPECIAL` row/total. Special Stat Split intentionally preserves the vanilla
`baseStats.special` field for engine/save compatibility and keeps Gen II SpA/SpD in its own
canonical table.

Result while both mods are enabled:
- battle/stat mechanics: unaffected;
- Pokédex Plus base-stat page: still displays the legacy single Special base stat and legacy total.

A small update to Pokédex Plus can make its page consume Special Stat Split's exported Gen II
base stats. Modifying its private local StatsScreen from this mod would require a brittle UI
monkey-patch, so it is intentionally not done in the core split mod.

## Link battles

The Gen1Recomp link payload carries species/level/DVs/Stat Exp rather than the calculated
SpA/SpD fields. Both peers reconstruct through wrapped `Stats.calc`. The manifest therefore
keeps `affects_link=true`; both peers must use the same gameplay-mod fingerprint.


### Pokédex Plus 1.3.0
Special Stat Split 1.0.1 uses the official `screens` registry to wrap `PokedexPlusStats` after Pokédex Plus loads. GEN II mode redraws only the base-stat rows with SP.ATK/SP.DEF and the six-stat BST. VANILLA delegates to the original screen.
