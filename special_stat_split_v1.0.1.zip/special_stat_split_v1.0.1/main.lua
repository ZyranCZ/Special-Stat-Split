-- SPECIAL STAT SPLIT v1.0.1
-- Public release for Gen1Recomp commit 60cf07fb0a1ffce0ec6d5d0d2f78a921a6d0b7da.
--
-- Scope: Generation II Special stat split ONLY.
-- Move physical/special categories remain type-based exactly as Gen I / Gen II.
-- The original Gen1Recomp damage formula, RNG, type handling and rulesets are preserved.
--
-- PUBLIC RELEASE:
-- Automated reference, battle-math, Lua and frozen-upstream integration gates pass.
-- In-game smoke and normal-mod-stack smoke were reported successful.
-- Live two-peer link play has not been manually tested; affects_link=true is retained.

local MOD_ID = "special_stat_split"
local PATCH_KEY = "__special_stat_split_dispatch_v1"
local unpack = table.unpack or unpack
local function pack(...) return { n = select("#", ...), ... } end

local function escapePattern(s)
  return (tostring(s):gsub("([^%w])", "%%%1"))
end

local function relabelMessages(messages, fromLabel, toLabel)
  if type(messages) ~= "table" then return messages end
  local pat = escapePattern(fromLabel)
  for i, msg in ipairs(messages) do
    if type(msg) == "string" then
      messages[i] = msg:gsub(pat, toLabel)
    end
  end
  return messages
end

-- Mod-local helpers/data are embedded in main.lua on purpose.
-- Gen1Recomp loads the manifest entry but does not add each mod directory
-- to Lua/LÖVE require paths, so mod-local library imports are not portable in packaged builds.
local GEN2_SPECIAL_BY_ID = {
  BULBASAUR = { dex = 1, spa = 65, spd = 65 },
  IVYSAUR = { dex = 2, spa = 80, spd = 80 },
  VENUSAUR = { dex = 3, spa = 100, spd = 100 },
  CHARMANDER = { dex = 4, spa = 60, spd = 50 },
  CHARMELEON = { dex = 5, spa = 80, spd = 65 },
  CHARIZARD = { dex = 6, spa = 109, spd = 85 },
  SQUIRTLE = { dex = 7, spa = 50, spd = 64 },
  WARTORTLE = { dex = 8, spa = 65, spd = 80 },
  BLASTOISE = { dex = 9, spa = 85, spd = 105 },
  CATERPIE = { dex = 10, spa = 20, spd = 20 },
  METAPOD = { dex = 11, spa = 25, spd = 25 },
  BUTTERFREE = { dex = 12, spa = 80, spd = 80 },
  WEEDLE = { dex = 13, spa = 20, spd = 20 },
  KAKUNA = { dex = 14, spa = 25, spd = 25 },
  BEEDRILL = { dex = 15, spa = 45, spd = 80 },
  PIDGEY = { dex = 16, spa = 35, spd = 35 },
  PIDGEOTTO = { dex = 17, spa = 50, spd = 50 },
  PIDGEOT = { dex = 18, spa = 70, spd = 70 },
  RATTATA = { dex = 19, spa = 25, spd = 35 },
  RATICATE = { dex = 20, spa = 50, spd = 70 },
  SPEAROW = { dex = 21, spa = 31, spd = 31 },
  FEAROW = { dex = 22, spa = 61, spd = 61 },
  EKANS = { dex = 23, spa = 40, spd = 54 },
  ARBOK = { dex = 24, spa = 65, spd = 79 },
  PIKACHU = { dex = 25, spa = 50, spd = 40 },
  RAICHU = { dex = 26, spa = 90, spd = 80 },
  SANDSHREW = { dex = 27, spa = 20, spd = 30 },
  SANDSLASH = { dex = 28, spa = 45, spd = 55 },
  NIDORAN_F = { dex = 29, spa = 40, spd = 40 },
  NIDORINA = { dex = 30, spa = 55, spd = 55 },
  NIDOQUEEN = { dex = 31, spa = 75, spd = 85 },
  NIDORAN_M = { dex = 32, spa = 40, spd = 40 },
  NIDORINO = { dex = 33, spa = 55, spd = 55 },
  NIDOKING = { dex = 34, spa = 85, spd = 75 },
  CLEFAIRY = { dex = 35, spa = 60, spd = 65 },
  CLEFABLE = { dex = 36, spa = 85, spd = 90 },
  VULPIX = { dex = 37, spa = 50, spd = 65 },
  NINETALES = { dex = 38, spa = 81, spd = 100 },
  JIGGLYPUFF = { dex = 39, spa = 45, spd = 25 },
  WIGGLYTUFF = { dex = 40, spa = 75, spd = 50 },
  ZUBAT = { dex = 41, spa = 30, spd = 40 },
  GOLBAT = { dex = 42, spa = 65, spd = 75 },
  ODDISH = { dex = 43, spa = 75, spd = 65 },
  GLOOM = { dex = 44, spa = 85, spd = 75 },
  VILEPLUME = { dex = 45, spa = 100, spd = 90 },
  PARAS = { dex = 46, spa = 45, spd = 55 },
  PARASECT = { dex = 47, spa = 60, spd = 80 },
  VENONAT = { dex = 48, spa = 40, spd = 55 },
  VENOMOTH = { dex = 49, spa = 90, spd = 75 },
  DIGLETT = { dex = 50, spa = 35, spd = 45 },
  DUGTRIO = { dex = 51, spa = 50, spd = 70 },
  MEOWTH = { dex = 52, spa = 40, spd = 40 },
  PERSIAN = { dex = 53, spa = 65, spd = 65 },
  PSYDUCK = { dex = 54, spa = 65, spd = 50 },
  GOLDUCK = { dex = 55, spa = 95, spd = 80 },
  MANKEY = { dex = 56, spa = 35, spd = 45 },
  PRIMEAPE = { dex = 57, spa = 60, spd = 70 },
  GROWLITHE = { dex = 58, spa = 70, spd = 50 },
  ARCANINE = { dex = 59, spa = 100, spd = 80 },
  POLIWAG = { dex = 60, spa = 40, spd = 40 },
  POLIWHIRL = { dex = 61, spa = 50, spd = 50 },
  POLIWRATH = { dex = 62, spa = 70, spd = 90 },
  ABRA = { dex = 63, spa = 105, spd = 55 },
  KADABRA = { dex = 64, spa = 120, spd = 70 },
  ALAKAZAM = { dex = 65, spa = 135, spd = 85 },
  MACHOP = { dex = 66, spa = 35, spd = 35 },
  MACHOKE = { dex = 67, spa = 50, spd = 60 },
  MACHAMP = { dex = 68, spa = 65, spd = 85 },
  BELLSPROUT = { dex = 69, spa = 70, spd = 30 },
  WEEPINBELL = { dex = 70, spa = 85, spd = 45 },
  VICTREEBEL = { dex = 71, spa = 100, spd = 60 },
  TENTACOOL = { dex = 72, spa = 50, spd = 100 },
  TENTACRUEL = { dex = 73, spa = 80, spd = 120 },
  GEODUDE = { dex = 74, spa = 30, spd = 30 },
  GRAVELER = { dex = 75, spa = 45, spd = 45 },
  GOLEM = { dex = 76, spa = 55, spd = 65 },
  PONYTA = { dex = 77, spa = 65, spd = 65 },
  RAPIDASH = { dex = 78, spa = 80, spd = 80 },
  SLOWPOKE = { dex = 79, spa = 40, spd = 40 },
  SLOWBRO = { dex = 80, spa = 100, spd = 80 },
  MAGNEMITE = { dex = 81, spa = 95, spd = 55 },
  MAGNETON = { dex = 82, spa = 120, spd = 70 },
  FARFETCH_D = { dex = 83, spa = 58, spd = 62 },
  DODUO = { dex = 84, spa = 35, spd = 35 },
  DODRIO = { dex = 85, spa = 60, spd = 60 },
  SEEL = { dex = 86, spa = 45, spd = 70 },
  DEWGONG = { dex = 87, spa = 70, spd = 95 },
  GRIMER = { dex = 88, spa = 40, spd = 50 },
  MUK = { dex = 89, spa = 65, spd = 100 },
  SHELLDER = { dex = 90, spa = 45, spd = 25 },
  CLOYSTER = { dex = 91, spa = 85, spd = 45 },
  GASTLY = { dex = 92, spa = 100, spd = 35 },
  HAUNTER = { dex = 93, spa = 115, spd = 55 },
  GENGAR = { dex = 94, spa = 130, spd = 75 },
  ONIX = { dex = 95, spa = 30, spd = 45 },
  DROWZEE = { dex = 96, spa = 43, spd = 90 },
  HYPNO = { dex = 97, spa = 73, spd = 115 },
  KRABBY = { dex = 98, spa = 25, spd = 25 },
  KINGLER = { dex = 99, spa = 50, spd = 50 },
  VOLTORB = { dex = 100, spa = 55, spd = 55 },
  ELECTRODE = { dex = 101, spa = 80, spd = 80 },
  EXEGGCUTE = { dex = 102, spa = 60, spd = 45 },
  EXEGGUTOR = { dex = 103, spa = 125, spd = 65 },
  CUBONE = { dex = 104, spa = 40, spd = 50 },
  MAROWAK = { dex = 105, spa = 50, spd = 80 },
  HITMONLEE = { dex = 106, spa = 35, spd = 110 },
  HITMONCHAN = { dex = 107, spa = 35, spd = 110 },
  LICKITUNG = { dex = 108, spa = 60, spd = 75 },
  KOFFING = { dex = 109, spa = 60, spd = 45 },
  WEEZING = { dex = 110, spa = 85, spd = 70 },
  RHYHORN = { dex = 111, spa = 30, spd = 30 },
  RHYDON = { dex = 112, spa = 45, spd = 45 },
  CHANSEY = { dex = 113, spa = 35, spd = 105 },
  TANGELA = { dex = 114, spa = 100, spd = 40 },
  KANGASKHAN = { dex = 115, spa = 40, spd = 80 },
  HORSEA = { dex = 116, spa = 70, spd = 25 },
  SEADRA = { dex = 117, spa = 95, spd = 45 },
  GOLDEEN = { dex = 118, spa = 35, spd = 50 },
  SEAKING = { dex = 119, spa = 65, spd = 80 },
  STARYU = { dex = 120, spa = 70, spd = 55 },
  STARMIE = { dex = 121, spa = 100, spd = 85 },
  MR_MIME = { dex = 122, spa = 100, spd = 120 },
  SCYTHER = { dex = 123, spa = 55, spd = 80 },
  JYNX = { dex = 124, spa = 115, spd = 95 },
  ELECTABUZZ = { dex = 125, spa = 95, spd = 85 },
  MAGMAR = { dex = 126, spa = 100, spd = 85 },
  PINSIR = { dex = 127, spa = 55, spd = 70 },
  TAUROS = { dex = 128, spa = 40, spd = 70 },
  MAGIKARP = { dex = 129, spa = 15, spd = 20 },
  GYARADOS = { dex = 130, spa = 60, spd = 100 },
  LAPRAS = { dex = 131, spa = 85, spd = 95 },
  DITTO = { dex = 132, spa = 48, spd = 48 },
  EEVEE = { dex = 133, spa = 45, spd = 65 },
  VAPOREON = { dex = 134, spa = 110, spd = 95 },
  JOLTEON = { dex = 135, spa = 110, spd = 95 },
  FLAREON = { dex = 136, spa = 95, spd = 110 },
  PORYGON = { dex = 137, spa = 85, spd = 75 },
  OMANYTE = { dex = 138, spa = 90, spd = 55 },
  OMASTAR = { dex = 139, spa = 115, spd = 70 },
  KABUTO = { dex = 140, spa = 55, spd = 45 },
  KABUTOPS = { dex = 141, spa = 65, spd = 70 },
  AERODACTYL = { dex = 142, spa = 60, spd = 75 },
  SNORLAX = { dex = 143, spa = 65, spd = 110 },
  ARTICUNO = { dex = 144, spa = 95, spd = 125 },
  ZAPDOS = { dex = 145, spa = 125, spd = 90 },
  MOLTRES = { dex = 146, spa = 125, spd = 85 },
  DRATINI = { dex = 147, spa = 50, spd = 50 },
  DRAGONAIR = { dex = 148, spa = 70, spd = 70 },
  DRAGONITE = { dex = 149, spa = 100, spd = 100 },
  MEWTWO = { dex = 150, spa = 154, spd = 90 },
  MEW = { dex = 151, spa = 100, spd = 100 },
}
local GEN2_SPECIAL_BY_DEX = {}
for _, row in pairs(GEN2_SPECIAL_BY_ID) do GEN2_SPECIAL_BY_DEX[row.dex] = row end

local SplitStats = {}
local function calcSplitStat(base, dv, statExp, level)
  local ev = math.floor(math.min(255, math.ceil(math.sqrt(statExp or 0))) / 4)
  return math.floor(((base + (dv or 0)) * 2 + ev) * level / 100) + 5
end
SplitStats.calcOne = calcSplitStat
function SplitStats.baseFor(speciesDef)
  if type(speciesDef) ~= "table" then return nil end
  local row = speciesDef.id and GEN2_SPECIAL_BY_ID[speciesDef.id]
  if not row and speciesDef.dex then row = GEN2_SPECIAL_BY_DEX[speciesDef.dex] end
  return row
end
function SplitStats.calculate(speciesDef, level, dvs, statExp, vanillaSpecial)
  local row = SplitStats.baseFor(speciesDef)
  if not row then return vanillaSpecial, vanillaSpecial end
  dvs = dvs or {}
  statExp = statExp or {}
  local dv = dvs.special or 0
  local exp = statExp.special or 0
  return calcSplitStat(row.spa, dv, exp, level), calcSplitStat(row.spd, dv, exp, level)
end
function SplitStats.attach(stats, speciesDef, level, dvs, statExp)
  if type(stats) ~= "table" then return stats end
  local spa, spd = SplitStats.calculate(speciesDef, level, dvs, statExp, stats.special)
  stats.specialAttack = spa
  stats.specialDefense = spd
  return stats
end

return function(mod)
  local Stats = require("src.pokemon.Stats")
  local Damage = require("src.battle.Damage")
  local Experience = require("src.battle.Experience")
  local ItemEffects = require("src.inventory.ItemEffects")
  local MoveEffects = require("src.battle.MoveEffects")
  local SummaryMenu = require("src.ui.SummaryMenu")
  local BattleState = require("src.battle.BattleState")
  local Font = require("src.render.Font")
  local Strings = require("src.core.Strings")
  local SaveData = require("src.core.SaveData")

  mod.options:define({
    {
      key = "mode",
      label = "SPECIAL STATS (RESTART)",
      type = "choice",
      default = "gen2",
      choices = {
        { "VANILLA", "vanilla" },
        { "GEN II (SP. ATK / SP. DEF)", "gen2" },
      },
    },
  })

  -- Capture once at load time: changing this option requires save + restart.
  local active = tostring(mod.options:get("mode") or "gen2") == "gen2"

  -- A single shared dispatcher state means a hot-reloaded copy can update the
  -- implementation without stacking wrappers on top of wrappers.
  local state = rawget(Stats, PATCH_KEY)
  if not state then
    state = {
      active = false,
      split = nil,
      originalCalc = Stats.calc,
      originalEnsure = Stats.ensure,
      originalDamage = Damage.compute,
      originalExperience = Experience.apply,
      originalItemUse = ItemEffects.use,
      originalSummaryDraw = SummaryMenu.draw,
      originalStatBoxDraw = BattleState.StatBox and BattleState.StatBox.draw,
      originalSave = SaveData.save,
      derivedStats = setmetatable({}, { __mode = "k" }),
    }
    rawset(Stats, PATCH_KEY, state)

    -- Track exactly which stat tables received fields from THIS mod. The weak
    -- set lets SaveData.save remove only our derived fields before serialization
    -- without touching another mod that might use similarly named keys.
    state.attach = function(stats, speciesDef, level, dvs, statExp)
      state.split.attach(stats, speciesDef, level, dvs, statExp)
      if type(stats) == "table" then state.derivedStats[stats] = true end
      return stats
    end

    -- Keep vanilla fields intact for compatibility. Add two derived fields.
    Stats.calc = function(speciesDef, level, dvs, statExp)
      local out = state.originalCalc(speciesDef, level, dvs, statExp)
      if state.active and state.split then
        state.attach(out, speciesDef, level, dvs, statExp)
      end
      return out
    end

    Stats.ensure = function(speciesDef, mon)
      local out = state.originalEnsure(speciesDef, mon)
      if state.active and state.split and type(out) == "table" and type(out.stats) == "table" then
        state.attach(out.stats, speciesDef, out.level or 1, out.dvs or {}, out.statExp or {})
      end
      return out
    end

    -- Do NOT reimplement Gen1Recomp's damage formula. For a special move,
    -- temporarily alias the legacy "special" operand to attacker SpA and
    -- defender SpD, call the exact upstream Damage.compute, then restore.
    Damage.compute = function(ruleset, attacker, defender, move, opts)
      if not state.active or not state.split or not attacker or not defender then
        return state.originalDamage(ruleset, attacker, defender, move, opts)
      end

      local category = move and move.category
      if category == nil and move and move.type then
        category = require("src.battle.TypeChart").category(move.type)
      end
      if category ~= "special" then
        return state.originalDamage(ruleset, attacker, defender, move, opts)
      end

      -- Existing saves may contain mon.stats without the new derived fields.
      -- Only fill missing split fields here.  `curStats` can be a transformed
      -- battle-stat table whose SpA/SpD deliberately belong to the copied
      -- target species; recomputing them from battler.def would silently
      -- revert Transform to the user's original species for special damage.
      local function ensureCurrentSplit(b)
        if not (b and b.mon and b.def and b.curStats) then return end
        if b.curStats.specialAttack == nil or b.curStats.specialDefense == nil then
          state.attach(b.curStats, b.def, b.mon.level or 1,
                       b.mon.dvs or {}, b.mon.statExp or {})
        end
      end
      ensureCurrentSplit(attacker)
      ensureCurrentSplit(defender)

      local acs, dcs = attacker.curStats, defender.curStats
      local ast, dst = attacker.stages or {}, defender.stages or {}
      attacker.stages, defender.stages = ast, dst

      local save = {
        acsSpecial = acs.special,
        dcsSpecial = dcs.special,
        astSpecial = ast.special,
        dstSpecial = dst.special,
      }

      acs.special = acs.specialAttack or acs.special
      dcs.special = dcs.specialDefense or dcs.special
      ast.special = ast.specialAttack or 0
      dst.special = dst.specialDefense or 0

      local result = pack(pcall(state.originalDamage, ruleset, attacker, defender, move, opts))

      acs.special = save.acsSpecial
      dcs.special = save.dcsSpecial
      ast.special = save.astSpecial
      dst.special = save.dstSpecial

      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end

    -- Summary page 1: replace only the legacy four-stat block after the
    -- frozen upstream screen has rendered. This avoids duplicating the rest
    -- of SummaryMenu (sprites, palettes, types, OT/ID, page 2). The compact
    -- one-line layout fits five stats into the original 10x10 tile box.
    SummaryMenu.draw = function(self)
      state.originalSummaryDraw(self)
      if not state.active or not state.split or self.page ~= 1 or not self.mon then
        return
      end
      local mon = self.mon
      local def = self.game and self.game.data and self.game.data.pokemon
                  and self.game.data.pokemon[mon.species]
      if def then
        mon.stats = mon.stats or Stats.calc(def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
        state.attach(mon.stats, def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
      end
      local st = mon.stats or {}
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.rectangle("fill", 0, 64, 80, 80)
      Font.drawBox(0, 8, 10, 10)
      love.graphics.setColor(0, 0, 0, 1)
      local rows = {
        { "ATK", st.attack }, { "DEF", st.defense }, { "SPEED", st.speed },
        -- The summary box is only 10 tiles wide. Six fixed-width glyphs
        -- ("SP.ATK") would collide with the 3-digit value column, so the two
        -- split labels use compact five-glyph forms here only.
        { "SPATK", st.specialAttack or st.special },
        { "SPDEF", st.specialDefense or st.special },
      }
      for i, r in ipairs(rows) do
        -- Interior of Font.drawBox(0,8,10,10) is x=8..71, y=72..135.
        -- Five 8px labels occupy x=8..47; 3-digit values occupy x=48..71.
        local y = 72 + (i - 1) * 14
        Font.draw(Strings(r[1]), 8, y)
        Font.draw(("%3d"):format(r[2] or 0), 48, y)
      end
      love.graphics.setColor(1, 1, 1, 1)
    end

    -- Level-up StatBox: same principle as SummaryMenu. Keep the upstream
    -- state/update flow and replace only its draw routine with five rows.
    if BattleState.StatBox and type(state.originalStatBoxDraw) == "function" then
      BattleState.StatBox.draw = function(self)
        if not state.active or not state.split or not self.mon then
          return state.originalStatBoxDraw(self)
        end
        local mon = self.mon
        local def = self.game and self.game.data and self.game.data.pokemon
                    and self.game.data.pokemon[mon.species]
        if def then
          mon.stats = mon.stats or Stats.calc(def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
          state.attach(mon.stats, def, mon.level or 1, mon.dvs or {}, mon.statExp or {})
        end
        local st = mon.stats or {}
        Font.drawBox(9, 2, 11, 10)
        love.graphics.setColor(0, 0, 0, 1)
        local rows = {
          { "ATK", st.attack }, { "DEF", st.defense }, { "SPEED", st.speed },
          { "SP.ATK", st.specialAttack or st.special },
          { "SP.DEF", st.specialDefense or st.special },
        }
        for i, r in ipairs(rows) do
          -- Interior of Font.drawBox(9,2,11,10) is x=80..151, y=24..87.
          -- "SP.ATK"/"SP.DEF" occupy x=80..127; values x=128..151.
          local y = 24 + (i - 1) * 14
          Font.draw(Strings(r[1]), 80, y)
          Font.draw(("%3d"):format(r[2] or 0), 128, y)
        end
        love.graphics.setColor(1, 1, 1, 1)
      end
    end

    -- Keep the on-disk save schema vanilla. Gen1Recomp serializes the full
    -- save table, including mon.stats, so derived SpA/SpD fields would otherwise
    -- leak into save.lua. Strip only stat tables tracked by this mod, call the
    -- exact upstream save routine, and restore in-memory fields even on error.
    SaveData.save = function(data, mods)
      if not state.active or not state.split then
        return state.originalSave(data, mods)
      end
      local removed, seen = {}, {}
      local function walk(value)
        if type(value) ~= "table" or seen[value] then return end
        seen[value] = true
        if state.derivedStats[value] then
          for _, key in ipairs({ "specialAttack", "specialDefense" }) do
            if value[key] ~= nil then
              removed[#removed + 1] = { tbl = value, key = key, value = value[key] }
              value[key] = nil
            end
          end
        end
        for _, child in pairs(value) do walk(child) end
      end
      walk(data)
      local result = pack(pcall(state.originalSave, data, mods))
      for i = #removed, 1, -1 do
        local r = removed[i]
        r.tbl[r.key] = r.value
      end
      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end

    -- Gen II keeps one shared Special Stat Exp. The defeated Pokémon's
    -- Special Attack base stat is the value added to that shared bucket.
    Experience.apply = function(data, mon, defeatedDef, level, isTrainer,
                                numParticipants, traded)
      if not state.active or not state.split or not defeatedDef then
        return state.originalExperience(data, mon, defeatedDef, level, isTrainer,
                                        numParticipants, traded)
      end
      local row = state.split.baseFor(defeatedDef)
      if not row or not defeatedDef.baseStats then
        return state.originalExperience(data, mon, defeatedDef, level, isTrainer,
                                        numParticipants, traded)
      end
      local old = defeatedDef.baseStats.special
      defeatedDef.baseStats.special = row.spa
      local result = pack(pcall(state.originalExperience, data, mon, defeatedDef,
                                level, isTrainer, numParticipants, traded))
      defeatedDef.baseStats.special = old
      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end

    -- X SPECIAL becomes a Sp. Atk stage boost. We preserve ItemEffects.use
    -- exactly and redirect only its temporary "special" stage slot.
    ItemEffects.use = function(data, saveData, itemId, target, battle, moveIndex, ow)
      if not state.active or itemId ~= "X_SPECIAL" or not battle or not battle.player then
        return state.originalItemUse(data, saveData, itemId, target, battle, moveIndex, ow)
      end
      local stages = battle.player.stages or {}
      battle.player.stages = stages
      local old = stages.special
      stages.special = stages.specialAttack or 0
      local result = pack(pcall(state.originalItemUse, data, saveData, itemId, target,
                                battle, moveIndex, ow))
      stages.specialAttack = stages.special or 0
      stages.special = old
      if result[1] then
        relabelMessages(result[3], Strings("SPECIAL"), Strings("SP. ATK"))
      end
      if not result[1] then error(result[2], 0) end
      return unpack(result, 2, result.n)
    end
  end

  state.active = active
  state.split = SplitStats

  -- Move-effect wrappers use the official move_effects registry. Calling the
  -- original record keeps Gen1Recomp's messages, Substitute/Mist behavior,
  -- chance rolls, and other edge cases; only the legacy stage slot is aliased.
  local function aliasStageRun(effectId, side, newKey)
    local originalRecord = MoveEffects.RECORDS[effectId]
    local originalRun = originalRecord and originalRecord.run
    if type(originalRun) ~= "function" then return end
    mod.content.move_effects:patch(effectId, {
      run = function(ctx)
        if not state.active then return originalRun(ctx) end
        local who = side == "user" and ctx.user or ctx.target
        if not who then return originalRun(ctx) end
        local stages = who.stages or {}
        who.stages = stages
        local old = stages.special
        stages.special = stages[newKey] or 0
        local result = pack(pcall(originalRun, ctx))
        stages[newKey] = stages.special or 0
        stages.special = old
        if result[1] then
          local label = newKey == "specialAttack" and "SP. ATK" or "SP. DEF"
          relabelMessages(result[2], Strings("SPECIAL"), Strings(label))
        end
        if not result[1] then error(result[2], 0) end
        return unpack(result, 2, result.n)
      end,
    })
  end

  -- Gen II meanings:
  -- Growth / SPECIAL_UP1 -> Sp. Atk +1
  -- Amnesia / SPECIAL_UP2 -> Sp. Def +2
  -- Psychic secondary Special drop -> Sp. Def -1
  aliasStageRun("SPECIAL_UP1_EFFECT", "user", "specialAttack")
  aliasStageRun("SPECIAL_UP2_EFFECT", "user", "specialDefense")
  aliasStageRun("SPECIAL_DOWN_SIDE_EFFECT", "target", "specialDefense")

  -- Transform copies both split stats and the target's stage table. The
  -- original effect already copies stages; we only add the two derived stats.
  do
    local originalRecord = MoveEffects.RECORDS.TRANSFORM_EFFECT
    local originalRun = originalRecord and originalRecord.run
    if type(originalRun) == "function" then
      mod.content.move_effects:patch("TRANSFORM_EFFECT", {
        run = function(ctx)
          local result = pack(pcall(originalRun, ctx))
          if result[1] and state.active and ctx.user and ctx.target then
            if ctx.target.curStats and ctx.user.curStats then
              ctx.user.curStats.specialAttack =
                ctx.target.curStats.specialAttack or ctx.target.curStats.special
              ctx.user.curStats.specialDefense =
                ctx.target.curStats.specialDefense or ctx.target.curStats.special
            end
          end
          if not result[1] then error(result[2], 0) end
          return unpack(result, 2, result.n)
        end,
      })
    end
  end

  -- Optional Pokédex Plus 1.3.x compatibility.  Pokédex Plus exposes
  -- its Base Stats page through the normal screens registry, so this can be
  -- composed without touching its private Lua locals.  The optional dependency
  -- guarantees Pokédex Plus registers the screen before this mod patches it.
  -- In VANILLA mode the original factory and draw path are returned untouched.
  do
    local pokedexPlus = type(mod.find) == "function" and mod.find("pokedex_plus") or nil
    local screens = mod.content and mod.content.screens
    if pokedexPlus and screens and type(screens.get) == "function"
        and type(screens.patch) == "function" then
      local originalRecord = screens:get("PokedexPlusStats")
      local originalNew = type(originalRecord) == "table" and originalRecord.new or nil
      if type(originalNew) == "function" then
        screens:patch("PokedexPlusStats", {
          new = function(game, opts)
            local screen = originalNew(game, opts)
            if not state.active or not state.split or type(screen) ~= "table" then
              return screen
            end

            local species = screen.species or (type(opts) == "table" and (opts.species or opts[1]))
            local def = game and game.data and game.data.pokemon and game.data.pokemon[species]
            local row = def and state.split.baseFor(def) or nil
            local stats = screen.stats
            local originalDraw = screen.draw
            if not row or type(stats) ~= "table" or type(originalDraw) ~= "function" then
              return screen
            end

            stats.specialAttack = row.spa
            stats.specialDefense = row.spd
            stats.total = (tonumber(stats.hp) or 0)
              + (tonumber(stats.attack) or 0)
              + (tonumber(stats.defense) or 0)
              + (tonumber(stats.speed) or 0)
              + row.spa + row.spd

            -- Let Pokédex Plus render its own header/type/footer exactly as-is,
            -- then replace only the legacy stat rows with a compact 7-row block.
            screen.draw = function(self)
              originalDraw(self)
              love.graphics.setColor(1, 1, 1, 1)
              love.graphics.rectangle("fill", 8, 40, 144, 88)
              love.graphics.setColor(0, 0, 0, 1)
              local labels = {
                { "HP", self.stats.hp },
                { "ATTACK", self.stats.attack },
                { "DEFENSE", self.stats.defense },
                { "SPEED", self.stats.speed },
                { "SP.ATK", self.stats.specialAttack },
                { "SP.DEF", self.stats.specialDefense },
                { "TOTAL", self.stats.total },
              }
              for i, statRow in ipairs(labels) do
                local y = 44 + (i - 1) * 12
                Font.draw(statRow[1], 16, y)
                local value = ("%03d"):format(statRow[2] or 0)
                Font.draw(value, 144 - Font.width(value), y)
              end
              love.graphics.setColor(1, 1, 1, 1)
            end
            return screen
          end,
        })
        mod.log:info("Pokédex Plus Base Stats compatibility enabled")
      else
        mod.log:warn("Pokédex Plus detected, but PokedexPlusStats screen was not available")
      end
    end
  end

  mod.exports = mod.exports or {}
  mod.exports.specialSplitActive = function() return state.active end
  -- Small inter-mod API for UI mods (for example a Pokédex base-stat page).
  -- Returns nil in VANILLA mode so consumers can fall back to legacy SPECIAL.
  mod.exports.getSpecialBaseStats = function(species)
    if not state.active or not state.split then return nil end
    local def = type(species) == "table" and species or { id = species }
    local row = state.split.baseFor(def)
    if not row then return nil end
    return { specialAttack = row.spa, specialDefense = row.spd }
  end
  mod.exports.attachSplitStats = function(mon, speciesDef)
    if not state.active or not mon or not speciesDef then return mon end
    mon.stats = mon.stats or Stats.calc(speciesDef, mon.level or 1, mon.dvs or {}, mon.statExp or {})
    state.attach(mon.stats, speciesDef, mon.level or 1, mon.dvs or {}, mon.statExp or {})
    return mon
  end
end
