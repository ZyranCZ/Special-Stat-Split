# SPECIAL STAT SPLIT — locked specification

Target upstream: Gen1Recomp commit `60cf07fb0a1ffce0ec6d5d0d2f78a921a6d0b7da`.

## In scope
- Split the single calculated `SPECIAL` into `SP. ATK` and `SP. DEF`.
- Use Generation II–V Kanto base Sp. Atk / Sp. Def values.
- Keep ONE shared `dvs.special`.
- Keep ONE shared `statExp.special`.
- Special damage reads attacker Sp. Atk and defender Sp. Def.
- Growth / X Special affect Sp. Atk.
- Amnesia affects Sp. Def.
- Psychic's Special secondary drop affects Sp. Def.
- Transform copies both split battle stats.
- Light Screen remains the special-defense screen through the existing damage path.
- Preserve current Gen1Recomp damage formula, RNG, STAB, type multipliers and rulesets.

## Explicitly out of scope
- Generation IV per-move physical/special split.
- Natures, abilities, held items, modern EVs/IVs.
- Porting the complete Generation II damage engine.
- New moves or type changes.

## Compatibility principle
The legacy calculated `stats.special` field remains present for compatibility, but split-enabled battle damage must use the derived SpA / SpD aliases. This minimizes collateral breakage in unrelated mods.
